﻿using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoNovedadesMonica.Views.Shared
{
    public partial class ReporteApartado : System.Web.Mvc.ViewPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           if (!IsPostBack)
            {
                List<Apartados> apartados = null;
                using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
                {
                    apartados = dc.Apartados.OrderBy(a => a.idApartado).ToList();
                    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/ApartadosReport.rdlc");
                    ReportViewer1.LocalReport.DataSources.Clear();
                    ReportDataSource rdc = new ReportDataSource("ApartadosDataSet", apartados);
                    ReportViewer1.LocalReport.DataSources.Add(rdc);
                    ReportViewer1.LocalReport.Refresh();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           /* SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=NovedadesMonica;Integrated Security=True");//Connection String 
            SqlDataAdapter da = new SqlDataAdapter("apartadoFecha", cn); //nombre del procedimiento almacenado
            DataTable dt = new DataTable();
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@date", SqlDbType.DateTime).Value = Convert.ToDateTime(TextBox1.Text);
            da.Fill(dt);
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportDataSource rp = new ReportDataSource("ApartadosDataSet", dt);
            ReportViewer1.LocalReport.DataSources.Add(rp);
            ReportViewer1.LocalReport.Refresh();*/

        }
    }
}