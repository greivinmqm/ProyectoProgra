﻿using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoNovedadesMonica.Views.Shared
{
    public partial class ReporteCuentasPagar : System.Web.Mvc.ViewPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<CuentasPorPagar> cuentasPagar = null;
                using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
                {
                    cuentasPagar = dc.CuentasPorPagar.OrderBy(a => a.idCuentaPagar).ToList();
                    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/CuentasXPagarReport.rdlc");
                    ReportViewer1.LocalReport.DataSources.Clear();
                    ReportDataSource rdc = new ReportDataSource("CuentasPagarDataSet", cuentasPagar);
                    ReportViewer1.LocalReport.DataSources.Add(rdc);
                    ReportViewer1.LocalReport.Refresh();
                }
            }
        }
    }
}