﻿using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoNovedadesMonica.Views.Shared
{
    public partial class ReporteApartadoGrafico : System.Web.Mvc.ViewPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<Apartados> apartados = null;
                using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
                {
                    apartados = dc.Apartados.OrderBy(a => a.idApartado).ToList();
                    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/ApartadosDataAnalysis.rdlc");
                    ReportViewer1.LocalReport.DataSources.Clear();
                    ReportDataSource rdc = new ReportDataSource("ApartadosDataSet", apartados);
                    ReportViewer1.LocalReport.DataSources.Add(rdc);
                    ReportViewer1.LocalReport.Refresh();
                }
            }

        }
    }
}