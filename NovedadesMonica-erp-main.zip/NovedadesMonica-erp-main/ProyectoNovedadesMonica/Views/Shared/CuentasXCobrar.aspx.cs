﻿using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoNovedadesMonica.Views.Shared
{
    public partial class CuentasXCobrar : System.Web.Mvc.ViewPage

    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<CuentasPorCobrar> cuentaspCobrar = null;
                using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
                {
                    cuentaspCobrar = dc.CuentasPorCobrar.OrderBy(a => a.idCuentaCobrar).ToList();
                    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/CuentasXCobrarReport.rdlc");
                    ReportViewer1.LocalReport.DataSources.Clear();
                    ReportDataSource rdc = new ReportDataSource("CuentasCobrarDataSet", cuentaspCobrar);
                    ReportViewer1.LocalReport.DataSources.Add(rdc);
                    ReportViewer1.LocalReport.Refresh();
                }
            }
        }
    }
}