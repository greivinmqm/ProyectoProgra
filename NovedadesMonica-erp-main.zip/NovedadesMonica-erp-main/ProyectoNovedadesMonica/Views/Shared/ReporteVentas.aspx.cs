﻿using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProyectoNovedadesMonica.Views.Shared
{
    public partial class ReporteVentas : System.Web.Mvc.ViewPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<Ventas> ventas = null;
                using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
                {
                    ventas = dc.Ventas.OrderBy(a => a.idVenta).ToList();
                    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/VentasReport.rdlc");
                    ReportViewer1.LocalReport.DataSources.Clear();
                    ReportDataSource rdc = new ReportDataSource("VentasDataSet", ventas);
                    ReportViewer1.LocalReport.DataSources.Add(rdc);
                    ReportViewer1.LocalReport.Refresh();
                }
            }
        }
    }
}