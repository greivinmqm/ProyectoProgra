﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProyectoNovedadesMonica.ETL
{
    public class RecoveryPassword
    {
        public string token { get; set; }

        [Required]
        [DisplayName("confirma contraseña")]

        public string Password { get; set; }

        [Required]
        [DisplayName("Contraseña")]
        [Compare("Password")]
        public string Password2 { get; set; }

    }
}