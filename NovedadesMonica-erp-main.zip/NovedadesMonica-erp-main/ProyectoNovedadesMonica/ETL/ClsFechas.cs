﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoNovedadesMonica.ETL
{
    public class ClsFechas
    {

        public DateTime fechaInicio { get; set; }
        public DateTime fechaFin { get; set; }
        public string estado { get; set; }
    }
}