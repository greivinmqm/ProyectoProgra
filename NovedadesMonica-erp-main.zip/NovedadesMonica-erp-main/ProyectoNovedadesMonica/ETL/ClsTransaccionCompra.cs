﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoNovedadesMonica.ETL
{
    public class ClsTransaccionCompra
    {
        public decimal idCompra { get; set; }
        public string idProveedor { get; set; }
        public int idUsuario { get; set; }
        public string fecha { get; set; }
        public string anulada { get; set; }
        public string formaPago { get; set; }
        public decimal total { get; set; }
        public Nullable<decimal> abono { get; set; }
        public string tipoTransaccion { get; set; }

    }
}