﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoNovedadesMonica.ETL
{
    public class ClsProducto
    {
        public string idProducto { get; set; }
        public int idCategoria { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public int cantidad { get; set; }
        public string Tallas { get; set; }
        public decimal costo { get; set; }
        public decimal precio { get; set; }
        public decimal impuesto { get; set; }
        public string imagen { get; set; }
    }
}