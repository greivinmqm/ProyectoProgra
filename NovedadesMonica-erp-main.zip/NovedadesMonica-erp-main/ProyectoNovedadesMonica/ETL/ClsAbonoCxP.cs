﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoNovedadesMonica.ETL
{
    public class ClsAbonoCxP
    {
        public int idabono { get; set; }
        public int idCuentaPagar { get; set; }
        public int idUsuario { get; set; }
        public decimal abono { get; set; }
        public System.DateTime fecha { get; set; }
        public string formaPago { get; set; }
        public decimal pendiente { get; set; }
        public decimal total { get; set; }
    }
}