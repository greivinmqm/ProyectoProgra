﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Controllers
{
    public class VentasDetalleController : Controller
    {
        VentaDetalleModels model = new VentaDetalleModels();
        // GET: VentasDetalle
        public ActionResult Venta()
        {
            ViewBag.listaProductos = model.listaProductos();
            return View("Venta", model.getVentasTemp());
        }

        [HttpPost]
        public ActionResult revisarCodAjax(string codigo)
        {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Productos
                             where x.idProducto == codigo
                             select x).FirstOrDefault();
                if (datos != null)
                {
                    ClsProducto prod = new ClsProducto();
                    prod.idProducto = datos.idProducto;
                    prod.descripcion = datos.descripcion;
                    prod.precio = datos.precio;
                    prod.cantidad = datos.cantidad;


                    return Json(prod, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(null, JsonRequestBehavior.DenyGet);
                }
            }
        }


        public ActionResult agregarLinea(VentaTemp venta)
        {

            model.agregarLinea(venta);
            ViewBag.listaProductos = model.listaProductos();
            return RedirectToAction("Venta", "VentasDetalle");
        }


        public ActionResult eliminarLineaAjax(int id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.VentaTemp
                                 where x.idVentTemp == id
                                 select x).FirstOrDefault();
                    //se valida si datos es nulo es porque no existe el user y no puede borrar.
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                        model.removeLinea(datos, contexto);
                        //se envia ese mensaje peor realmente no aporta mucho, solo es para que en el documento java script
                        //se sepa que todo se hizo bien y por eso llega el json correctamente. 
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        public ActionResult limpiarLineas()
        {
            if (model.limpiarLineas())
            {
                return Json("borrado", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        [HttpPost]
        public ActionResult addVentaModal()
        {
            try
            {
                ViewBag.listaClientes = model.listaClientes();
                ViewBag.listaPago = model.listaPago();
                ViewBag.listaAccion = model.listaAccion();
                return PartialView("ConfirmaVentaPartial", model.crearObjetoTransaccion());
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult newVentaAjax(string descuento, string total, string transaccion, string forma, string cliente, string abono )
        {

            try
            {
                decimal tot = Convert.ToDecimal(total, CultureInfo.CreateSpecificCulture("en-US"));
                if (model.cajaAbierta())
                {


                    if (transaccion == "Venta")
                    {
                        decimal desc = Convert.ToDecimal(descuento, CultureInfo.CreateSpecificCulture("en-US"));
                        ClsTransaccion transac = (new ClsTransaccion
                        {
                            idCliente = cliente,
                            fecha = DateTime.Now.ToString("dd-MMMM-yyyy"),
                            anulada = "n",
                            formaPago = forma,
                            tipoTransaccion = transaccion,
                            descuento = desc,
                            total = tot
                        });
                        int user = Convert.ToInt32(Session["User"]);
                        if (model.addVenta(transac, user))
                        {
                            BitacorasController bitacora = new BitacorasController();
                            Bitacora bita = (new Bitacora
                            {
                                operacion = "Agregar",
                                idUsuario = Convert.ToInt32(Session["User"]),
                                fechaModificacion = DateTime.Now,
                                tabla = "Ventas"

                            });
                            bitacora.CreateBitacora(bita);
                            model.BorrarLineas();
                            return Json("Agregado", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(null, JsonRequestBehavior.DenyGet);
                        }
                    }
                    else if (transaccion == "Apartado")
                    {
                        decimal abonoIni = Convert.ToDecimal(abono, CultureInfo.CreateSpecificCulture("en-US"));

                        ClsTransaccion transac = (new ClsTransaccion
                        {
                            idCliente = cliente,
                            fecha = DateTime.Now.ToString("dd-MMMM-yyyy"),
                            anulada = "n",
                            formaPago = forma,
                            tipoTransaccion = transaccion,
                            abono = abonoIni,
                            total = tot
                        });
                        int user = Convert.ToInt32(Session["User"]);
                        if (model.addApartado(transac, user))
                        {
                            BitacorasController bitacora = new BitacorasController();
                            Bitacora bita = (new Bitacora
                            {
                                operacion = "Agregar",
                                idUsuario = Convert.ToInt32(Session["User"]),
                                fechaModificacion = DateTime.Now,
                                tabla = "Apartado"

                            });
                            //bitacora.CreateBitacora(bita);
                            model.BorrarLineas();
                            return Json("Agregado", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(null, JsonRequestBehavior.DenyGet);
                        }
                    }
                }
                //aquí iria el nuevo método que haría Yulandi para lo que serían los apartados.

                return Json(null, JsonRequestBehavior.DenyGet);

            }
            catch (Exception e)
            {

                return Json(null, JsonRequestBehavior.DenyGet);

            }

        }

        public ActionResult VistaVentas()
        {
            return RedirectToAction("Ventas","Ventas");
        }

    }

}