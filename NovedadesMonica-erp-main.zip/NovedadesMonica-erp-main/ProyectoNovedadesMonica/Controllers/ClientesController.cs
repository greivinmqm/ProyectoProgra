﻿using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models;

namespace ProyectoNovedadesMonica.Controllers
{
    public class ClientesController : Controller
    {
        // GET: Clientes
        ClientesModel modelo = new ClientesModel();
        public ActionResult Clientes()
        {
            try
            {
                return View("Clientes", modelo.consultaCLientes());

            }
            catch (Exception e)
            {
                //el tema de excepciones todavía no está, pero lo ideal sería enviar todos los mjs
                //con errores a una tabla y si se da un error que lo redirija a uno a esa vista de errores. 
                throw;
            }
        }

        [HttpPost]
        public ActionResult getNewClientAjax()
        {
            try
            {

               
                //hacemos un usuario vacío y lo enviamos porque es lo que recibe la vista parcial (Razor)
                Clientes cliente = new Clientes();
                return PartialView("ClienteAgregarPartial", cliente);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult agregarCliente(Clientes cliente)
        {
            try
            {
                modelo.AgregarCliente(cliente);
                BitacorasController bitacora = new BitacorasController();
                Bitacora bita = (new Bitacora
                {
                    operacion = "Agregar",
                    idUsuario = Convert.ToInt32(Session["User"]),
                    fechaModificacion = DateTime.Now,
                    tabla = "Clientes"

                });
                bitacora.CreateBitacora(bita);
                return RedirectToAction("Clientes", "Clientes");

            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult editClienteAjax(string id)
        {
            try
            {
                return PartialView("ClienteEditarPartial", modelo.getCliente(id));

            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult mantenimientoCliente(Clientes clientes, string submit)
        {
            try
            {
                if (submit == "Editar")
                {
                    modelo.editarCliente(clientes);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Editar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Clientes"

                    });
                    bitacora.CreateBitacora(bita);
                    return RedirectToAction("Clientes", "Clientes");

                }
                return RedirectToAction("Clientes", "Clientes");
            }
            catch (Exception)
            {
                throw;
            }
        }




        public ActionResult eliminarCliente(string id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Clientes
                                 where x.idCliente == id.ToString()
                                 select x).FirstOrDefault();
                    //se valida si datos es nulo es porque no existe el user y no puede borrar.
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                        modelo.removeCliente(datos, contexto);
                        BitacorasController bitacora = new BitacorasController();
                        Bitacora bita = (new Bitacora
                        {
                            operacion = "Eliminar",
                            idUsuario = Convert.ToInt32(Session["User"]),
                            fechaModificacion = DateTime.Now,
                            tabla = "Clientes"

                        });
                        bitacora.CreateBitacora(bita);
                        //se envia ese mensaje peor realmente no aporta mucho, solo es para que en el documento java script
                        //se sepa que todo se hizo bien y por eso llega el json correctamente. 
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}