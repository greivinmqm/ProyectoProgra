﻿    using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models;
using ProyectoNovedadesMonica.ETL;

namespace ProyectoNovedadesMonica.Controllers
{
    public class UsuariosController : Controller
    {
        /*Este es como el onload(), es lo que se ejecuta cada vez que se carga la página.*/

        UsuariosModels model = new UsuariosModels();
        // GET: Usuarios
        public ActionResult Usuarios()
        {
            try
            {
                return View("Usuarios", model.consultaUsuarios());

            }
            catch (Exception)
            {
                //el tema de excepciones todavía no está, pero lo ideal sería enviar todos los mjs
                //con errores a una tabla y si se da un error que lo redirija a uno a esa vista de errores. 
                throw;            }
        }

        //proceso que viene del llamodo post de la carpeta Funciones/usuario.
        /*Método llamado desde ajax, es para pasar la info necesaria al modal*/
        [HttpPost]
        public ActionResult getNewUserAjax()
        {
            try
            {
               
                ViewBag.ListaRoles = model.listaRoles();
                ViewBag.ListaEstado = model.listaEstado();               
                //hacemos un usuario vacío y lo enviamos porque es lo que recibe la vista parcial (Razor)
                Usuarios user = new Usuarios();
                return PartialView("UsuarioAgregarPartial", user);
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult agregarUsuario(Usuarios user)
        {
            try
            {
                model.AgregarUsuario(user);
                BitacorasController bitacora = new BitacorasController();
                Bitacora bita = (new Bitacora
                {
                    operacion = "Agregar",
                    idUsuario = Convert.ToInt32(Session["User"]),
                    fechaModificacion = DateTime.Now,
                    tabla = "Usuarios"

                });
                bitacora.CreateBitacora(bita);
                return RedirectToAction("Usuarios", "Usuarios");

            }
            catch (Exception)
            {
                throw;
            }       
        }

        //Toda la misma idea del otro método
        [HttpPost]
        public ActionResult editUserAjax(int id)
        {
            try
            {             
                ViewBag.ListaEstado = model.listaEstado();
                ViewBag.ListaRoles = model.listaRoles();
                return PartialView("UsuarioEditarPartial", model.getUser(id));

            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult mantenimientoUsuario(Usuarios usuarios, string submit)
        {
            try
            {
                if (submit == "Editar")
                {
                    model.editarUsuario(usuarios);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Editar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Usuarios"

                    });
                    bitacora.CreateBitacora(bita);
                    return RedirectToAction("Usuarios", "Usuarios");

                }
                return RedirectToAction("Usuarios", "Usuarios");
            }
            catch (Exception)
            {
                throw;
            }
        }


        public ActionResult eliminarUsuario(int id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Usuarios
                                 where x.idUsuario == id
                                 select x).FirstOrDefault();
                    //se valida si datos es nulo es porque no existe el user y no puede borrar.
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                       model.removeUsuario(datos, contexto);
                        BitacorasController bitacora = new BitacorasController();
                        Bitacora bita = (new Bitacora
                        {
                            operacion = "Eliminar",
                            idUsuario = Convert.ToInt32(Session["User"]),
                            fechaModificacion = DateTime.Now,
                            tabla = "Usuarios"

                        });
                        bitacora.CreateBitacora(bita);
                        //se envia ese mensaje peor realmente no aporta mucho, solo es para que en el documento java script
                        //se sepa que todo se hizo bien y por eso llega el json correctamente. 
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }        
        }
        public ActionResult revisarCedAjax(string cedula)
        {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Usuarios
                             where x.cedula == cedula
                             select x).FirstOrDefault();
                if (datos == null)
                {
                    return Json("sin uso", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(null, JsonRequestBehavior.DenyGet);
                }
            }
        }


        [HttpGet]
        public ActionResult cambioContrasena()
        {
            RecoveryPassword model = new RecoveryPassword();
            return View("cambioContrasena", model);
        }


        [HttpPost]
        public ActionResult cambioContrasena(RecoveryPassword recover)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(recover);
                }
                using (var context = new NovedadesMonicaEntities())
                {
                    int userId = Convert.ToInt32(Session["User"]);

                    var user = (from x in context.Usuarios
                                where x.idUsuario == userId
                                select x).FirstOrDefault();
                    if (user != null)
                    {
                        user.contrasena = recover.Password;
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
            ViewBag.Message = "¡Contraseña cambiada con éxito!";
            return RedirectToAction("Index", "Home");
        }

        public ActionResult revisarCorreoAjax(string correo)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Usuarios
                                 where x.correo == correo
                                 select x).FirstOrDefault();
                    if (datos == null)
                    {
                        return Json("sin uso", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            
        }

    }
}