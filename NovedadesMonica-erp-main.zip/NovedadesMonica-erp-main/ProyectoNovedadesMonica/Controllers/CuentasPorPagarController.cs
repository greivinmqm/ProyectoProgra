﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Controllers
{
    public class CuentasPorPagarController : Controller
    {
        CuentasPagarModels model = new CuentasPagarModels();

        public ActionResult ConsultaCXP()
        {
            return View("ConsultaCXP", model.cuentasPagarActivas());
        }

        public ActionResult aplicarFiltros(DateTime? fechaFin, DateTime? fechaIni, string estado)
        {
            if (fechaFin == null || fechaIni == null)
            {
                DateTime fechaFin2 = DateTime.MinValue;
                DateTime fechaIni2 = DateTime.MinValue;
                return View("ConsultaCXP", model.CuentasFecha(fechaFin2, fechaIni2, estado));

            }
            return View("ConsultaCXP", model.CuentasFecha(fechaFin.Value, fechaIni.Value, estado));
        }

        public ActionResult vistaAbonos(int cuenta)
        {
            ViewBag.cuenta = cuenta;
            return View("vistaAbonos", model.abonosRealizados(cuenta));
        }

        [HttpPost]
        public ActionResult vistaModalAbono(int cuenta)
        {
            int user = Convert.ToInt32(Session["User"]);
            ViewBag.listaFormaPago = model.listaEstado();
            return PartialView("AbonoModalPartial", model.nuevoAbono(cuenta, user));
        }

        [HttpPost]
        public ActionResult newAbono(int idCuenta, decimal abono, int idabono, string formaPago)
        {
            int user = Convert.ToInt32(Session["User"]);
            if (model.newAbonoModel(idCuenta, abono, idabono, user, formaPago))
            {
                return Json("borrado", JsonRequestBehavior.AllowGet);

            }
            else
            {
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        public ActionResult VistaReporte()
        {
            return View();
        }



        //public ActionResult VistaGrafico()
        //{
        //    return View();
        //}

    }

}