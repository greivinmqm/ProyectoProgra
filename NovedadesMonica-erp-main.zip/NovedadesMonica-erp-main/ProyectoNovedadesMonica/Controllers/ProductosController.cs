﻿//using Microsoft.Build.Tasks;
using Microsoft.Reporting.WebForms;
using ProyectoNovedadesMonica.Models;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Warning = Microsoft.Reporting.WebForms.Warning;

namespace ProyectoNovedadesMonica.Controllers
{
    public class ProductosController : Controller
    {
        ProductosModels model = new ProductosModels();
        // GET: Productos
        public ActionResult Productos()
        {
            return View("Productos", model.getProductos());
        }


        [HttpPost]
        public ActionResult getNewProductAjax()
            {
            try
            {
                ViewBag.listaCategorias = model.listaCategorias();
                Productos producto = new Productos();
                return PartialView("ProductoAgregarPartial", producto);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file, Productos productos)
        {
            try
            {
                if (file != null && file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var path = Path.Combine(Server.MapPath("~/Images/"), fileName);
                    file.SaveAs(path);
                    using (var context = new NovedadesMonicaEntities())
                    {
                        productos.imagen = fileName;
                        context.Productos.Add(productos);
                        context.SaveChanges();
                        BitacorasController bitacora = new BitacorasController();
                        Bitacora bita = (new Bitacora
                        {
                            operacion = "Agregar",
                            idUsuario = Convert.ToInt32(Session["User"]),
                            fechaModificacion = DateTime.Now,
                            tabla = "Clientes"

                        });
                        bitacora.CreateBitacora(bita);
                    }
                }
                else
                {
                    model.addProducto(productos);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Agregar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Productos"

                    });
                    bitacora.CreateBitacora(bita);
                }
            }
            catch (Exception)
            {
                throw;
            }         
            return RedirectToAction("Productos");
        }

        [HttpPost]
        public ActionResult editarProductoVista(string submit)
        {
            using (var context = new NovedadesMonicaEntities()) 
            {
                var datos = (from x in context.Productos
                             where x.idProducto == submit
                             select x).FirstOrDefault();
                ViewBag.ListaCategorias = model.listaCategorias();
                BitacorasController bitacora = new BitacorasController();
                Bitacora bita = (new Bitacora
                {
                    operacion = "Editar",
                    idUsuario = Convert.ToInt32(Session["User"]),
                    fechaModificacion = DateTime.Now,
                    tabla = "Productos"

                });
                bitacora.CreateBitacora(bita);
                return View("EditarProductos", datos);
            }           
        }

        public ActionResult eliminarProducto(string id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Productos
                                 where x.idProducto == id
                                 select x).FirstOrDefault();
                    //se valida si datos es nulo es porque no existe el user y no puede borrar.
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                        model.removeProducto(datos, contexto);
                        BitacorasController bitacora = new BitacorasController();
                        Bitacora bita = (new Bitacora
                        {
                            operacion = "Eliminar",
                            idUsuario = Convert.ToInt32(Session["User"]),
                            fechaModificacion = DateTime.Now,
                            tabla = "Productos"

                        });
                        bitacora.CreateBitacora(bita);
                        //se envia ese mensaje peor realmente no aporta mucho, solo es para que en el documento java script
                        //se sepa que todo se hizo bien y por eso llega el json correctamente. 
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult editarProducto(HttpPostedFileBase file, Productos productos)
        {
            try
            {
                
                    using (var context = new NovedadesMonicaEntities())
                    {
                        var datos = (from x in context.Productos
                                     where x.idProducto == productos.idProducto
                                     select x).FirstOrDefault();
                    if (file != null && file.ContentLength > 0)
                    {

                        var fileName = Path.GetFileName(file.FileName);
                        if (fileName != datos.imagen)
                        {
                            var path = Path.Combine(Server.MapPath("~/Images/"), fileName);
                            file.SaveAs(path);
                            datos.imagen = fileName;

                        }
                    }

                        datos.nombre = productos.nombre;
                        datos.descripcion = productos.descripcion;
                        datos.cantidad = productos.cantidad;
                        datos.costo = productos.costo;
                        datos.idCategoria = productos.idCategoria;
                        datos.precio = productos.precio;
                        datos.impuesto = productos.impuesto;
                        datos.Tallas = productos.Tallas;
                        
                        context.SaveChanges();
                    }
                
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("Productos");
        }


        public ActionResult revisarCodAjax(string codigo)
        {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Productos
                             where x.idProducto == codigo
                             select x).FirstOrDefault();
                if (datos == null)
                {
                    return Json("sin uso", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(null, JsonRequestBehavior.DenyGet);
                }
            }
        }

        /* public ActionResult Report(string id)
         {
             Microsoft.Reporting.WebForms.LocalReport lr = new Microsoft.Reporting.WebForms.LocalReport();
             string path = Path.Combine(Server.MapPath("~/Report"), "productosReport.rdlc");
             if (System.IO.File.Exists(path))
             {
                 lr.ReportPath = path;
             }
             else
             {
                 return View("Productos");
             }
             List<Productos> cm = new List<Productos>();
             using (NovedadesMonicaEntities dc = new NovedadesMonicaEntities())
             {
                 cm = dc.Productos.ToList();
             }
             ReportDataSource rd = new ReportDataSource("ProductosDataSet", cm);
             lr.DataSources.Add(rd);
             string reportType = id;
             string mimeType;
             string encoding;
             string fileNameExtension;

             string deviceInfo =

             "<DeviceInfo>" +
             "  <OutputFormat>" + id + "</OutputFormat>" +
             "  <PageWidth>8.5in</PageWidth>" +
             "  <PageHeight>11in</PageHeight>" +
             "  <MarginTop>0.5in</MarginTop>" +
             "  <MarginLeft>1in</MarginLeft>" +
             "  <MarginRight>1in</MarginRight>" +
             "  <MarginBottom>0.5in</MarginBottom>" +
             "</DeviceInfo>";

             Warning[] warnings;
             string[] streams;
             byte[] renderedBytes;

             renderedBytes = lr.Render(
                 reportType,
                 deviceInfo,
                 out mimeType,
                 out encoding,
                 out fileNameExtension,
                 out streams,
                 out warnings);
             return File(renderedBytes, mimeType);
         }*/

        public ActionResult VistaReporte()
        {
            return View();
        }

        public ActionResult VistaGrafico()
        {
            return View();
        }

    }
}