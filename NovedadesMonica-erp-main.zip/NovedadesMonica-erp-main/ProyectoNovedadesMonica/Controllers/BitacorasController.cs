﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Controllers
{
    public class BitacorasController : Controller
    {
        private NovedadesMonicaEntities db = new NovedadesMonicaEntities();


        // GET: Bitacoras/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Bitacoras/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public void CreateBitacora(Bitacora bitacora)
        {
            if (ModelState.IsValid)
            {
                db.Bitacora.Add(bitacora);
                db.SaveChanges();
            }


        }



    }
}
