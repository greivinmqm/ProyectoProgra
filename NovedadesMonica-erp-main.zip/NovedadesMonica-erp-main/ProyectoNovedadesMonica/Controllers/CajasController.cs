﻿using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models;

namespace ProyectoNovedadesMonica.Controllers
{
    public class CajasController : Controller
    {
        CajasModel model = new CajasModel();
        // GET: Cajas
        public ActionResult Cajas()
        {
            try
            {
                return View("Cajas", model.consultaCajas());

            }
            catch (Exception e)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult getNewCajaAjax()
        {
            try
            {
                Cajas caja = new Cajas();
                return PartialView("CajaAgregarPartial", caja);
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult agregarCaja(Cajas caja)
        {
            try
            {
                if (!model.cajaAbierta())
                {
                    int id = Convert.ToInt32(Session["User"]);
                    model.AgregarCaja(caja, id);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Agregar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Cajas"

                    });
                    bitacora.CreateBitacora(bita);
                    return RedirectToAction("Cajas", "Cajas");
                }
                ViewBag.Message = "Solo puede abrir una caja al dia";
                return View("Cajas", model.consultaCajas());

            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult editCajaAjax(int id)
        {
            try
            {
                return PartialView("CajaEditarPartial", model.getCaja(id));

            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult mantenimientoCaja(Cajas cajas, string submit)
        {
            try
            {
                if (submit == "Cerrar" && cajas.estado=="Activo")
                {
                    model.editarCaja(cajas);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Editar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Cajas"

                    });
                    bitacora.CreateBitacora(bita);
                    return RedirectToAction("Cajas", "Cajas");

                }
                return RedirectToAction("Cajas", "Cajas");
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult revisarCajaUsuario(int id, int estado)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Cajas
                                 where x.idUsuario == id
                                 select x).FirstOrDefault();
                    if (datos == null)
                    {
                        return Json("sin uso", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}