﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models;

namespace ProyectoNovedadesMonica.Controllers
{

    public class ApartadoController : Controller
    {

        ApartadosModel model = new ApartadosModel();
        // GET: Apartado
        public ActionResult Apartados()
        {
            return View("Apartados", model.consultaApartados());
        }

        public ActionResult filtarFechas(DateTime fechaFin, DateTime fechaIni)
        {
            return View("Apartados", model.consultaApartadossFechas(fechaFin, fechaIni));
        }

        //public ActionResult vistaDetalleVenta(int id, DateTime fecha)
        //{
        //    return View("DetalleVenta", model.detalleVenta(id, fecha));
        //}

        public ActionResult VistaReporte()
        {
            return View();
        }

        public ActionResult VistaGrafico()
        {
            return View();
        }

    }
}