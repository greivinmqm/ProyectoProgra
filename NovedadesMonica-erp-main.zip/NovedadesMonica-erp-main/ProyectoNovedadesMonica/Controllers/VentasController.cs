﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models;
using ProyectoNovedadesMonica.Models.BaseEntity;


namespace ProyectoNovedadesMonica.Controllers
{
    public class VentasController : Controller
    {
        VentasModels model = new VentasModels();

        // GET: Ventas
        public ActionResult Ventas()
        {
            return View("Ventas", model.consultaVentas());
        }

        public ActionResult filtarFechas(DateTime fechaFin, DateTime fechaIni)
        {
            return View("Ventas", model.consultaVentasFechas(fechaFin, fechaIni));
        }

        public ActionResult vistaDetalleVenta(int id, DateTime fecha)
        {
            return View("DetalleVenta", model.detalleVenta(id, fecha));
        }

        public ActionResult anularVentaAjax(int id, DateTime fecha)
        {
            if (model.anularVenta(id, fecha))
            {
                return Json("anulado", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        public ActionResult VistaReporte()
        {
            return View();
        }

        public ActionResult VistaGrafico()
        {
            return View();
        }
    }
}