﻿using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models;

namespace ProyectoNovedadesMonica.Controllers
{
    public class ProveedoresController : Controller
    {

        ProveedoresModels model = new ProveedoresModels();
       
        public ActionResult Proveedores()
        {
            try
            {
                return View("Proveedores", model.consultaProveedores());

            }
            catch (Exception e)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult getNewProveedorAjax()
        {
            try
            {
                Proveedores proveedor = new Proveedores();
                return PartialView("ProveedorAgregarPartial", proveedor);
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult agregarProveedor(Proveedores proveedor)
        {
            try
            {
                model.AgregarProveedor(proveedor);
                BitacorasController bitacora = new BitacorasController();
                Bitacora bita = (new Bitacora
                {
                    operacion = "Insertar",
                    idUsuario = Convert.ToInt32(Session["User"]),
                    fechaModificacion = DateTime.Now,
                    tabla = "Proveedores"

                });
                bitacora.CreateBitacora(bita);
                return RedirectToAction("Proveedores", "Proveedores");

            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult editProveedorAjax(string id)
        {
            try
            {
                return PartialView("ProveedorEditarPartial", model.getProveedor(id));

            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpPost]
        public ActionResult mantenimientoProveedor(Proveedores proveedor, string submit)
        {
            try
            {
                if (submit == "Editar")
                {
                    model.editarProveedor(proveedor);
                    BitacorasController bitacora = new BitacorasController();
                    Bitacora bita = (new Bitacora
                    {
                        operacion = "Editar",
                        idUsuario = Convert.ToInt32(Session["User"]),
                        fechaModificacion = DateTime.Now,
                        tabla = "Proveedores"

                    });
                    bitacora.CreateBitacora(bita);
                    return RedirectToAction("Proveedores", "Proveedores");

                }
                return RedirectToAction("Proveedores", "Proveedores");
            }
            catch (Exception)
            {
                throw;
            }
        }


        public ActionResult eliminarProveedor(string id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Proveedores
                                 where x.idProveedor == id
                                 select x).FirstOrDefault();
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                        model.removeProveedor(datos, contexto);
                        BitacorasController bitacora = new BitacorasController();
                        Bitacora bita = (new Bitacora
                        {
                            operacion = "Eliminar",
                            idUsuario = Convert.ToInt32(Session["User"]),
                            fechaModificacion = DateTime.Now,
                            tabla = "Proveedores"

                        });
                        bitacora.CreateBitacora(bita);
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ActionResult revisarCedAjax(string cedula)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Proveedores
                                 where x.idProveedor == cedula
                                 select x).FirstOrDefault();
                    if (datos == null)
                    {
                        return Json("sin uso", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
           
        }
    }
}