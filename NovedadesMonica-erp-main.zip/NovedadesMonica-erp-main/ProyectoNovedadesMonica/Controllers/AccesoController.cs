﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;
using ProyectoNovedadesMonica.Models;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;
using ProyectoNovedadesMonica.ETL;

namespace ProyectoNovedadesMonica.Controllers
{

    public class AccesoController : Controller
    {
        string urlDomain = "https://localhost:44334/";

        // GET: Acceso
        public ActionResult Login()
        {
            return View();
        }

        [HttpGet]
        public ActionResult LogOut()
        {
            Session["UserObj"] = null;
            Session["User"] = "";
            Session["UserName"] = "";
            Session["UserRol"] = "";
            return View("Login");
        }
        [HttpPost]
        public ActionResult Login(string User, string Pass)
        {
            try
            {
                using (Models.BaseEntity.NovedadesMonicaEntities db= new Models.BaseEntity.NovedadesMonicaEntities())
                {
                    var oUser = (from d in db.Usuarios
                                 where d.correo == User.Trim() && d.contrasena == Pass.Trim() && d.estado=="Activo"
                                 select d).FirstOrDefault();
                    if (oUser == null)
                    {
                        ViewBag.Error = "Usuario o contraseña invalida";
                        return View();
                    }

                    Session["UserObj"] = oUser;
                    Session["User"] = oUser.idUsuario;
                    Session["UserName"] = oUser.nombre +" "+ oUser.primerApellido;
                    Session["UserRol"] = oUser.idrol;
                            
                }

                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }

        }
        [HttpGet]
        public ActionResult Recovery()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Recovery(string email)
        {
            try
            {
                if (email != null)
                {
                    string token = GetSha256(Guid.NewGuid().ToString());

                    using (var context = new NovedadesMonicaEntities())
                    {
                        var datos = (from x in context.Usuarios
                                     where x.correo == email
                                     select x).FirstOrDefault();
                        if (datos != null)
                        {
                            datos.tokenRecovery = token;
                            context.SaveChanges();

                            sendEmail(email, token);
                            ViewBag.Message = "¡Correo enviado con éxito!";
                            return View("Recovery");
                        }
                    }
                }
                return View();

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            
        }

        public ActionResult StartRecovery()
        {
            return View();
        }

        private string GetSha256(string str)
        {
            SHA256 sha = SHA256Managed.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] stream = null;
            StringBuilder sb = new StringBuilder();
            stream = sha.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }

        private void sendEmail(string email, string token)
        {
            string EmailOrigen = "novedadesmonica01@gmail.com";
            string contraseña = "Novedades01";
            string EmailDestino = email;
            string url=urlDomain+"/Acceso/RecoveryToken/?token="+token;
            MailMessage oMailMessage = new MailMessage(EmailOrigen, EmailDestino, "Recuperación de Contraseña",
                "<p>De parte de Novedades Mónica hemos recibida una solicitud para cambiar el correo</p><br>" +
                "<a href='"+url+"'>Click para recuperar</a>");
            oMailMessage.IsBodyHtml = true;
            SmtpClient oSmtpClient = new SmtpClient("smtp.gmail.com", 587);
            oSmtpClient.EnableSsl = true;
            oSmtpClient.UseDefaultCredentials = false;
            oSmtpClient.Credentials = new System.Net.NetworkCredential(EmailOrigen, contraseña);
            oSmtpClient.Send(oMailMessage);
            oSmtpClient.Dispose();
        }

        [HttpGet]
        public ActionResult RecoveryToken(string token)
        {
            RecoveryPassword model = new RecoveryPassword();
            model.token = token;
            return View("RecoveryToken", model);
        }


        [HttpPost]
        public ActionResult RecoveryToken(RecoveryPassword recover)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(recover);
                }
                using(var context = new NovedadesMonicaEntities())
                {
                    var user = (from x in context.Usuarios
                                where x.tokenRecovery == recover.token
                                select x).FirstOrDefault();
                    if (user!= null)
                    {
                        user.tokenRecovery = null;
                        user.contrasena = recover.Password;
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
            ViewBag.Message = "¡Contraseña cambiada con éxito!";
            return View("Login");
        }

    }

}