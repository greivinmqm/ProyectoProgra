﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Controllers
{
    public class CompraController : Controller
    {
        CompraModels model = new CompraModels();
        public ActionResult Compra()
        {
            ViewBag.listaCategorias = model.listaCategorias();
            return View("Compra", model.getCompraTemp());
        }

        [HttpPost]
        public ActionResult revisarCodAjax(string codigo)
        {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Productos
                             where x.idProducto == codigo
                             select x).FirstOrDefault();
                if (datos != null)
                {
                    CompraTemp compra = new CompraTemp();
                    compra.idProducto = datos.idProducto;
                    compra.nombre = datos.nombre;
                    compra.descripcion = datos.descripcion;
                    compra.idCategoria = datos.idCategoria;
                    compra.cantInventario = datos.cantidad;
                    compra.costo = datos.costo;
                    compra.precio = datos.precio;
                    compra.Tallas = datos.Tallas;
                    compra.imagen = datos.imagen;
                    return Json(compra, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return null;
                }
            }
        }


        public ActionResult agregarLinea(CompraTemp compra)
        {
            model.agregarLinea(compra);
            return RedirectToAction("Compra", "Compra");
        }


        public ActionResult eliminarLineaAjax(String id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.CompraTemp
                                 where x.idProducto == id
                                 select x).FirstOrDefault();
                    if (datos == null)
                    {
                        return Json(null, JsonRequestBehavior.DenyGet);
                    }
                    else
                    {
                        model.removeLinea(datos, contexto);
                        return Json("borrado", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        public ActionResult limpiarLineas()
        {
            if (model.limpiarLineas())
            {
                return Json("borrado", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(null, JsonRequestBehavior.DenyGet);
            }
        }

        [HttpPost]
        public ActionResult addCompraModal()
        {
            try
            {
                ViewBag.listaProveedores = model.listaProveedores();
                ViewBag.listaPago = model.listaPago();
                ViewBag.listaAccion = model.listaAccion();
                return PartialView("ConfirmaCompraPartial", model.crearObjetoTransaccionCompra());
            }
            catch (Exception)
            {
                throw;
            }
        }
        [HttpPost]
        public ActionResult newCompraAjax(string total, string transaccion, string forma, string Proveedor, string abono)
        {

            try
            {
                decimal tot = Convert.ToDecimal(total, CultureInfo.CreateSpecificCulture("en-US"));
                if (model.cajaAbierta())
                {


                    if (transaccion == "Contado")
                    {
                        if (model.addCompras())
                        {
                            model.BorrarLineas();
                            return Json("Agregado", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(null, JsonRequestBehavior.DenyGet);
                        }
                    }
                    else if (transaccion == "Credito")
                    {
                        decimal abonoIni = Convert.ToDecimal(abono, CultureInfo.CreateSpecificCulture("en-US"));

                        ClsTransaccionCompra transac = (new ClsTransaccionCompra
                        {
                            idProveedor = Proveedor,
                            fecha = DateTime.Now.ToString("dd-MMMM-yyyy"),
                            anulada = "n",
                            formaPago = forma,
                            tipoTransaccion = transaccion,
                            abono = abonoIni,
                            total = tot
                        });
                        int user = Convert.ToInt32(Session["User"]);
                        if (model.addCuentaPorPagar(transac, user))
                        {
                            model.BorrarLineas();
                            return Json("Agregado", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(null, JsonRequestBehavior.DenyGet);
                        }
                    }
                }

                return Json(null, JsonRequestBehavior.DenyGet);

            }
            catch (Exception e)
            {

                return Json(null, JsonRequestBehavior.DenyGet);

            }

        }
    }
}