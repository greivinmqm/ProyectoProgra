﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Models
{
    public class CompraModels
    {
        public List<SelectListItem> listaCategorias()
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    List<SelectListItem> listaCategorias;
                    listaCategorias = (from x in contexto.Categorias
                                       select new SelectListItem
                                       {
                                           Value = x.idCategoria.ToString(),
                                           Text = x.nombreCategoria
                                       }).ToList();
                    return listaCategorias;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
        public List<SelectListItem> listaProveedores()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Proveedores
                                 select x).ToList();
                    List<SelectListItem> listaProveedores;
                    listaProveedores = (from x in datos
                                     select new SelectListItem { Value = x.idProveedor.ToString(), Text = x.nombre + " " + x.primerApellido + " " + x.segundoApellido }).ToList();
                    return listaProveedores;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaPago()
        {
            try
            {
                List<SelectListItem> listaPago = new List<SelectListItem>(); ;
                listaPago.Add(new SelectListItem { Value = "Efectivo", Text = "Efectivo" });
                listaPago.Add(new SelectListItem { Value = "Tarjeta", Text = "Tarjeta" });
                return listaPago;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaAccion()
        {
            try
            {
                List<SelectListItem> listaAccion = new List<SelectListItem>(); ;
                listaAccion.Add(new SelectListItem { Value = "Contado", Text = "Contado" });
                listaAccion.Add(new SelectListItem { Value = "Credito", Text = "Credito" });
                return listaAccion;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<CompraTemp> getCompraTemp()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    List<CompraTemp> lista = new List<CompraTemp>();
                    var datos = (from x in context.CompraTemp
                                 select x).ToList();
                    return datos;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }

        public Boolean existeProducto(CompraTemp compra) 
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var productos = (from x in context.Productos
                                      select x).ToList();
                    foreach (var linea in productos)
                    {
                        if (compra.idProducto == linea.idProducto)
                        {
                            return true;
                        }
                    }
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void agregarLinea(CompraTemp compra)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var valida = (from x in context.CompraTemp
                                  where x.idProducto == compra.idProducto
                                  select x).FirstOrDefault();
                    if (valida == null)
                    {
                        addLineaNueva(compra);
                    }
                    else
                    {
                        actLineaExistente(context, compra, valida);
                    }
                    

                }
            }
            catch (Exception)
            {

                throw;
            }

        }


        public void addLineaNueva(CompraTemp compra)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    if (existeProducto(compra))
                    {
                        var datos = (from x in context.Productos
                                     where x.idProducto == compra.idProducto
                                     select x).FirstOrDefault();
                        datos.cantidad += compra.cantCompra.Value;
                    }
                    context.CompraTemp.Add(compra);
                    context.SaveChanges();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void actLineaExistente(NovedadesMonicaEntities _context, CompraTemp lineaNueva, CompraTemp lineaBD)
        {
            using (var context = _context)
            {
                if (existeProducto(lineaNueva))
                {
                    var datos = (from x in context.Productos
                                 where x.idProducto == lineaNueva.idProducto
                                 select x).FirstOrDefault();
                    datos.cantidad += lineaNueva.cantCompra.Value;
                }
                
                lineaBD.cantInventario += lineaNueva.cantCompra;
                lineaBD.cantCompra += lineaNueva.cantCompra;
                context.SaveChanges();
            }
        }

        public void removeLinea(CompraTemp linea, NovedadesMonicaEntities _contexto)
        {
            try
            {
                using (var contexto = _contexto)
                {
                    contexto.CompraTemp.Remove(linea);
                    if (existeProducto(linea))
                    {
                        removerCant(linea);
                    }
                    contexto.SaveChanges();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void removerCant(CompraTemp linea)
        {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Productos
                             where x.idProducto == linea.idProducto
                             select x).FirstOrDefault();
                datos.cantidad -= linea.cantCompra.Value;
                context.SaveChanges();

            }
        }

        public Boolean limpiarLineas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CompraTemp
                                 select x).ToList();
                    foreach (var linea in datos)
                    {
                        context.CompraTemp.Remove(linea);
                        removerCant(linea);
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false; ;
            }

        }

        public ClsTransaccionCompra crearObjetoTransaccionCompra()
        {
            ClsTransaccionCompra transaccion = (new ClsTransaccionCompra
            {
                idUsuario = 100,
                idProveedor = "1-1191-0908",
                fecha = DateTime.Now.ToString("dd-MMMM-yyyy"),
                anulada = "n",
                formaPago = "Efectivo",
                tipoTransaccion = "Contado",
                total = getTotalCompra()

            });

            return transaccion;
        }

        public decimal getTotalCompra()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CompraTemp
                                 select x).ToList();
                    decimal total = 0;
                    foreach (var linea in datos)
                    {
                        total += (linea.precio.Value * linea.cantCompra.Value);
                    }
                    return total;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Boolean BorrarLineas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CompraTemp
                                 select x).ToList();
                    foreach (var linea in datos)
                    {
                        context.CompraTemp.Remove(linea);
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false; ;
            }

        }

        public int getIdMaxCuentaCobrar()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastCuentaPagar();
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 100;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public Boolean addCompras()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CompraTemp
                                 select x).ToList();
                    var datos2 = (from x in context.Productos
                                 select x).ToList();
                    Boolean nuevo = true;
                    foreach (var compra in datos)
                    {
                        nuevo = true;
                        foreach (var prod in datos2)
                        {
                            if (compra.idProducto == prod.idProducto)
                            {
                                nuevo = false;
                            }
                        }
                        if (nuevo)
                        {
                            Productos products = (new Productos
                            {
                                idProducto = compra.idProducto,
                                idCategoria = (int)compra.idCategoria,
                                nombre = compra.nombre,
                                descripcion = compra.descripcion,
                                cantidad = (int)compra.cantCompra,
                                Tallas = compra.Tallas,
                                costo = (decimal)compra.costo,
                                precio = (decimal)compra.precio,
                                impuesto = 0,
                                imagen = compra.imagen
                            });
                            context.Productos.Add(products);
                            context.SaveChanges();
                        }
                    }
                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public Boolean addCuentaPorPagar(ClsTransaccionCompra transaccion, int idUser)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Proveedores
                                 where x.idProveedor == transaccion.idProveedor
                                 select x).FirstOrDefault();
                    CuentasPorPagar cuenta = (new CuentasPorPagar
                    {
                        idCuentaPagar = getIdMaxCuentaCobrar(),
                        idUsuario = idUser,
                        idProveedor = transaccion.idProveedor,
                        total = transaccion.total,
                        saldo = transaccion.abono,
                        descripcion = "",
                        fechaInicio = Convert.ToDateTime(transaccion.fecha),
                        pendiente = transaccion.total - transaccion.abono,
                        estado = "Pendiente",
                        Proveedor = datos.nombre + " " + datos.primerApellido + " " + datos.segundoApellido
                    });
                    addCompras();
                    context.CuentasPorPagar.Add(cuenta);
                    context.SaveChanges();
                    if (cuenta.idCuentaPagar != 0)
                    {
                        abonoInicial(transaccion, cuenta.idCuentaPagar, idUser);
                        return true;
                    }

                    return true;
                }
            }
            catch (Exception e)
            {

                    return false;
            }
        }

        public void abonoInicial(ClsTransaccionCompra transaccionCompra, int idCuenta, int user)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    AbonosCXP abono = (new AbonosCXP
                    {
                        idAbono = lastIdAbono(idCuenta),
                        idCuentaPagar = idCuenta,
                        idUsuario = user,
                        Abono = transaccionCompra.abono,
                        fecha = Convert.ToDateTime(transaccionCompra.fecha),
                        formaPago = transaccionCompra.formaPago,

                    });
                    context.AbonosCXP.Add(abono);
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public int lastIdAbono(int idCuenta)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastAbonoCXP(idCuenta);
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 1;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public Boolean cajaAbierta()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    DateTime fecha = DateTime.Now;
                    var datos = (from x in context.Cajas
                                 where x.estado == "Activo"
                                 select x).FirstOrDefault();
                    if (datos != null)
                    {
                        return true;

                    }
                    return false;
                }

            }
            catch (Exception)
            {

                return false;
            }

        }
    }
}