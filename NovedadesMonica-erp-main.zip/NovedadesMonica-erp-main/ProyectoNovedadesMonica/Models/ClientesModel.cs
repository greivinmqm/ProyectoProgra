﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Models.BaseEntity
{
    public class ClientesModel
    {
        public List<Clientes> consultaCLientes()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Clientes
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public void AgregarCliente(Clientes cliente)
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                contexto.Clientes.Add(cliente);
                contexto.SaveChanges();
                //lo que se hace es redirigir a método inicial Get, que es para recargar la página y actulizar la info.
            }
        }

        public Clientes getCliente(string id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    
                    var datos = (from x in contexto.Clientes
                                 where x.idCliente == id
                                 select x).FirstOrDefault();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void editarCliente(Clientes clientes)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    //usamos LinQ para obtener el usuario
                    var datos = (from x in contexto.Clientes
                                 where x.idCliente == clientes.idCliente
                                 select x).FirstOrDefault();
                    //para hacer el update se va a proceder a igualar cada uno de los objetos
                    //de datos(que es como el objeto propio de la BD) y el objeto que está recibiendo por parámetros
                    //que es toda la nueva información que el usuario envió.
                    datos.idCliente = clientes.idCliente;
                    datos.nombre = clientes.nombre;
                    datos.primerApellido = clientes.primerApellido;
                    datos.segundoApellido = clientes.segundoApellido;
                    datos.direccion = clientes.direccion;
                    datos.correo = clientes.correo;
                    datos.telefono = clientes.telefono;
                    
                    

                    //hago el commit
                    contexto.SaveChanges();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void removeCliente(Clientes clientes, NovedadesMonicaEntities _contexto)
        {
            using (var contexto = _contexto)
            {
                //borra el user y se hace el commit
                contexto.Clientes.Remove(clientes);
                contexto.SaveChanges();
            }

        }

    }
}