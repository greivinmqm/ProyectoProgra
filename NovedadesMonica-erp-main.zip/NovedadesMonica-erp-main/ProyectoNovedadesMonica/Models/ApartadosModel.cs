﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Models
{
    public class ApartadosModel
    {

        public List<Apartados> consultaApartados()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    DateTime fechaAct = DateTime.Parse(DateTime.Now.ToString("dd-MM-yyyy"));
                    var datos = (from x in context.Apartados
                                 where x.fecha == fechaAct
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Apartados> consultaApartadossFechas(DateTime fechFin, DateTime fechaIni)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    DateTime fechaAct = DateTime.Parse(DateTime.Now.ToString("dd-MM-yyyy"));
                    var datos = (from x in context.Apartados
                                 where x.fecha >= fechaIni && x.fecha <= fechFin
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}