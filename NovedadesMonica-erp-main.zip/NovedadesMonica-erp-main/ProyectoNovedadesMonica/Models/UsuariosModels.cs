﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Models
{
    public class UsuariosModels
    {
        //uso de linq para retornar una lista de usuarios.
        public List<Usuarios> consultaUsuarios()
        {
            try
            {
            using (var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Usuarios
                             select x).ToList();
                return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public List<SelectListItem> listaRoles()
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                var datos = (from x in contexto.Roles
                             select x).ToList();
                List<SelectListItem> listaRoles;
                listaRoles = (from x in datos
                                   select new SelectListItem { Value = x.idRol.ToString(), Text = x.nombreRol }).ToList();
                return listaRoles;
            }
        }
        public List<SelectListItem> listaEstado()
        {
            List<SelectListItem> listaEstado = new List<SelectListItem>();
            listaEstado.Add(new SelectListItem { Value = "Activo", Text = "Activo" });
            listaEstado.Add(new SelectListItem { Value = "Inactivo", Text = "Inactivo" });

            return listaEstado;
        }

        public void AgregarUsuario(Usuarios user)
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                contexto.Usuarios.Add(user);
                contexto.SaveChanges();
                //lo que se hace es redirigir a método inicial Get, que es para recargar la página y actulizar la info.
            }
        }

        public Usuarios getUser(int id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Usuarios
                                 where x.idUsuario == id
                                 select x).FirstOrDefault();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }          
        }

        public void editarUsuario(Usuarios usuarios)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    //usamos LinQ para obtener el usuario
                    var datos = (from x in contexto.Usuarios
                                 where x.idUsuario == usuarios.idUsuario
                                 select x).FirstOrDefault();
                    //para hacer el update se va a proceder a igualar cada uno de los objetos
                    //de datos(que es como el objeto propio de la BD) y el objeto que está recibiendo por parámetros
                    //que es toda la nueva información que el usuario envió.
                    datos.nombre = usuarios.nombre;
                    datos.primerApellido = usuarios.primerApellido;
                    datos.segundoApellido = usuarios.segundoApellido;
                    datos.telefono = usuarios.telefono;
                    datos.idrol = usuarios.idrol;
                    datos.cedula = usuarios.cedula;
                    datos.correo = usuarios.correo;
                    datos.estado = usuarios.estado;

                    //hago el commit
                    contexto.SaveChanges();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void removeUsuario(Usuarios usuarios, NovedadesMonicaEntities _contexto)
        {
            using (var contexto = _contexto) {
                //borra el user y se hace el commit
                contexto.Usuarios.Remove(usuarios);
                contexto.SaveChanges();
            }

        }
    }
}