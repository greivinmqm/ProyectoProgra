﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Models
{
    public class VentaDetalleModels
    {

        public List<SelectListItem> listaProductos()
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Productos
                                 select x).ToList();
                    List<SelectListItem> listaProductos;
                    listaProductos = (from x in datos
                                  select new SelectListItem { Value = x.idProducto.ToString(), Text = x.nombre }).ToList();
                    return listaProductos;
                } 
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaClientes()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Clientes
                                 select x).ToList();
                    List<SelectListItem> listaClientes;
                    listaClientes = (from x in datos
                                      select new SelectListItem { Value = x.idCliente.ToString(), Text = x.nombre+" "+x.primerApellido+" "+x.segundoApellido }).ToList();
                    return listaClientes;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaPago()
        {
            try
            {
                List<SelectListItem> listaPago = new List<SelectListItem>(); ;
                listaPago.Add(new SelectListItem { Value = "Efectivo", Text = "Efectivo" });
                listaPago.Add(new SelectListItem { Value = "Tarjeta", Text = "Tarjeta" });
                return listaPago;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaAccion()
        {
            try
            {
                List<SelectListItem> listaAccion = new List<SelectListItem>(); ;
                listaAccion.Add(new SelectListItem { Value = "Venta", Text = "Venta" });
                listaAccion.Add(new SelectListItem { Value = "Apartado", Text = "Apartado" });
                return listaAccion;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<VentaTemp> getVentasTemp()
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    List<VentaTemp> lista = new List<VentaTemp>();
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    return datos;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }

        public void agregarLinea(VentaTemp venta)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var valida = (from x in context.VentaTemp
                                  where x.idProducto == venta.idProducto
                                  select x).FirstOrDefault();
                    if (valida==null)
                    {
                        addLineaNueva(venta);
                    }
                    else
                    {
                        actLineaExistente(context, venta, valida);
                    }

                   
                }
            }
            catch (Exception)
            {

                throw;
            }
          
        }


        public void addLineaNueva(VentaTemp venta)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Productos
                                 where x.idProducto == venta.idProducto
                                 select x).FirstOrDefault();
                    datos.cantidad -= venta.cantidad.Value;
                    VentaTemp linea = new VentaTemp();

                    var query = context.lastVentaTemp();
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            linea.idVentTemp = 1;

                        }
                        else
                        {
                            linea.idVentTemp = max.Value + 1;
                        }
                    }

                    linea.idProducto = datos.idProducto;
                    linea.nombreProducto = datos.nombre;
                    linea.descripcion = datos.descripcion;
                    linea.precio = datos.precio;
                    linea.cantidad = venta.cantidad;
                    linea.impuesto = datos.impuesto;

                    context.VentaTemp.Add(linea);
                    context.SaveChanges();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void actLineaExistente(NovedadesMonicaEntities _context, VentaTemp lineaNueva, VentaTemp lineaBD)
        {
            using(var context = _context)
            {
                var datos = (from x in context.Productos
                             where x.idProducto == lineaNueva.idProducto
                             select x).FirstOrDefault();
                datos.cantidad -= lineaNueva.cantidad.Value;
                lineaBD.cantidad += lineaNueva.cantidad;
                context.SaveChanges();
            }
        }

        public void removeLinea(VentaTemp linea, NovedadesMonicaEntities _contexto)
        {
            try
            {
                using (var contexto = _contexto)
                {

                    //borra el user y se hace el commit
                    contexto.VentaTemp.Remove(linea);
                    agregarCant(linea);
                    contexto.SaveChanges();
                }
            }
            catch (Exception) { 
            
                throw;
            }
        }

        public void agregarCant(VentaTemp linea)
        {
            using(var context = new NovedadesMonicaEntities())
            {
                var datos = (from x in context.Productos
                             where x.idProducto == linea.idProducto
                             select x).FirstOrDefault();
                datos.cantidad += linea.cantidad.Value;
                context.SaveChanges();

            }
        }

        public Boolean limpiarLineas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    foreach (var linea in datos)
                    {
                        context.VentaTemp.Remove(linea);
                        agregarCant(linea);
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false; ;
            } 
            
        }

        public ClsTransaccion crearObjetoTransaccion()
        {
            ClsTransaccion transaccion = (new ClsTransaccion
            {
                idUsuario = 100,
                idCliente = "1-1191-0908",
                fecha = DateTime.Now.ToString("dd-MMMM-yyyy"),
                anulada = "n",
                formaPago="Efectivo",
                tipoTransaccion="Venta",
                descuento=0,
                total = getTotalVenta()

            });

            return transaccion;
        }

        public decimal getTotalVenta()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    decimal total = 0;
                    foreach (var linea in datos)
                    {
                        total += (linea.precio.Value*linea.cantidad.Value);
                    }
                    return total;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Boolean addVenta(ClsTransaccion transaccion, int idUser)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {

                    Ventas venta = (new Ventas
                    {
                        idVenta = getIdMaxVenta(transaccion),
                        fecha = Convert.ToDateTime(transaccion.fecha),
                        idCliente = transaccion.idCliente,
                        formaPago = transaccion.formaPago,
                        descuento = transaccion.descuento,
                        total = transaccion.total,
                        idUsuario = idUser,
                        anulada = "n"
                    }) ;
                    context.Ventas.Add(venta);
                    context.SaveChanges();
                    addDetallesVenta(venta.idVenta, venta.fecha);
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public int getIdMaxVenta(ClsTransaccion transaccion)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastVentaDia(Convert.ToDateTime(transaccion.fecha));
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 1;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        public void addDetallesVenta(int id, DateTime fecha)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    foreach(var linea in datos)
                    {
                        ventasDetalle venta = (new ventasDetalle
                        {
                            idVenta = id,
                            idProducto = linea.idProducto,
                            precio = linea.precio.Value,
                            costo = 0,
                            impuesto = linea.impuesto.Value,
                            cantidad = linea.cantidad.Value,
                            fecha = fecha
                        }) ;
                        context.ventasDetalle.Add(venta);
                        context.SaveChanges();
                    } 
                }
            }
            catch (Exception e)
            {

                throw;
            }    
        }

        public Boolean BorrarLineas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    foreach (var linea in datos)
                    {
                        context.VentaTemp.Remove(linea);
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false; ;
            }

        }


        public Boolean addApartado(ClsTransaccion transaccion, int idUser)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {

                    Apartados apartado = (new Apartados
                    {
                        idApartado = getIdMaxApartado(transaccion),
                        fecha = Convert.ToDateTime(transaccion.fecha),
                        idCliente = transaccion.idCliente,
                        abono = transaccion.abono,
                        total = transaccion.total,
                        idUsuario = idUser,
                        impuesto = 0
                    });
                    context.Apartados.Add(apartado);
                    context.SaveChanges();
                    addDetallesApartado(apartado.idApartado, apartado.fecha);
                    int idCuenta = addCuentaPorCobrar(apartado);
                    if (idCuenta!=0)
                    {
                        abonoInicial(apartado, transaccion.formaPago, idCuenta);
                        return true;
                    }

                    return true;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public int getIdMaxApartado(ClsTransaccion transaccion)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastApartadoDia(Convert.ToDateTime(transaccion.fecha));
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 1;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public int getIdMaxCuentaCobrar()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastCuentaCobrar();
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 100;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public void addDetallesApartado(int id, DateTime fecha)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.VentaTemp
                                 select x).ToList();
                    foreach (var linea in datos)
                    {
                        ApartadosDetalle apartado = (new ApartadosDetalle
                        {
                            idApartado = id,
                            idProducto = linea.idProducto,
                            precio = linea.precio.Value,
                            impuesto = linea.impuesto.Value,
                            cantidad = linea.cantidad.Value,
                            fecha = fecha
                        });
                        context.ApartadosDetalle.Add(apartado);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public int addCuentaPorCobrar(Apartados apartado)
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Usuarios
                                 where x.idUsuario == apartado.idUsuario
                                 select x).FirstOrDefault();
                    CuentasPorCobrar cuenta = (new CuentasPorCobrar
                    {
                        idCuentaCobrar = getIdMaxCuentaCobrar(),
                        idApartado = apartado.idApartado,
                        idUsuario = apartado.idUsuario,
                        total = apartado.total,
                        saldo = apartado.abono,
                        descripcion = "",
                        fecha = apartado.fecha,
                        pendiente = apartado.total-apartado.abono,
                        estado = "Pendiente",
                        cliente = datos.nombre +" "+ datos.primerApellido +" "+ datos.segundoApellido
                    });
                    context.CuentasPorCobrar.Add(cuenta);
                    context.SaveChanges();
                    return cuenta.idCuentaCobrar;
                }
            }
            catch (Exception)
            {

                return 0;
            }
        }

        public void abonoInicial(Apartados apartado, string formaPago, int idCuenta)
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    AbonosCXC abono = (new AbonosCXC
                    {
                        idabono = lastIdAbono(apartado.fecha, idCuenta),
                        idCuentaCobrar = idCuenta,
                        idUsuario = apartado.idUsuario,
                        abono = apartado.abono,
                        fecha = apartado.fecha,
                        formaPago = formaPago,
                        
                    });
                    context.AbonosCXC.Add(abono);
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public int lastIdAbono(DateTime fecha, int idCuenta)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    int id;
                    var query = context.lastAbonoCXC(idCuenta);
                    foreach (var max in query)
                    {
                        if (max == null)
                        {
                            id = 1;
                            return id;
                        }
                        else
                        {
                            id = max.Value + 1;
                            return id;
                        }
                    }
                    return 0;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public Boolean cajaAbierta()
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    DateTime fecha = DateTime.Now;
                    var datos = (from x in context.Cajas
                                 where x.estado == "Activo"
                                 select x).FirstOrDefault();
                    if (datos != null)
                    {
                        return true;

                    }
                    return false;
                }

            }
            catch (Exception)
            {

                return false;
            }

        }
    }
}