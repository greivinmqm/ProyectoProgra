﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Models
{
    public class CuentasPagarModels
    {
        public List<CuentasPorPagar> cuentasPagarActivas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {

                    var datos = (from x in context.CuentasPorPagar
                                 where x.estado == "Pendiente"
                                 select x).ToList();

                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<CuentasPorPagar> CuentasFecha(DateTime fechaFin, DateTime fechaIni, string estado)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    if (estado == "" && fechaFin != DateTime.MinValue)
                    {
                        var datos = (from x in context.CuentasPorPagar
                                     where x.fechaInicio <= fechaFin && x.fechaInicio >= fechaIni
                                     select x).ToList();
                        return datos;

                    }
                    else if (estado != "" && fechaFin == DateTime.MinValue)
                    {
                        var datos = (from x in context.CuentasPorPagar
                                     where x.estado == estado
                                     select x).ToList();
                        return datos;

                    }
                    else
                    {
                        var datos = (from x in context.CuentasPorPagar
                                     where x.fechaInicio <= fechaFin && x.fechaInicio >= fechaIni && x.estado == estado
                                     select x).ToList();
                        return datos;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<AbonosCXP> abonosRealizados(int cuenta)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.AbonosCXP
                                 where x.idCuentaPagar == cuenta
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public ClsAbonoCxP nuevoAbono(int cuenta, int user)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    CompraModels model = new CompraModels();
                    var datos = (from x in context.CuentasPorPagar
                                 where x.idCuentaPagar == cuenta
                                 select x).FirstOrDefault();

                    ClsAbonoCxP abono = (new ClsAbonoCxP
                    {
                        idabono = model.lastIdAbono(cuenta),
                        idUsuario = user,
                        idCuentaPagar = cuenta,
                        fecha = DateTime.Now,
                        pendiente = datos.pendiente.Value,
                        total = datos.total.Value
                    });

                    return abono;

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<SelectListItem> listaEstado()
        {
            try
            {
                List<SelectListItem> listaEstado = new List<SelectListItem>(); ;
                listaEstado.Add(new SelectListItem { Value = "Efectivo", Text = "Efectivo" });
                listaEstado.Add(new SelectListItem { Value = "Tarjeta", Text = "Tarjeta" });
                return listaEstado;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Boolean newAbonoModel(int cuenta, decimal abono, int idAbono, int user, string pago)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CuentasPorPagar
                                 where x.idCuentaPagar == cuenta
                                 select x).FirstOrDefault();
                    datos.saldo += abono;
                    datos.pendiente -= abono;
                    if (datos.pendiente == 0)
                    {
                        datos.estado = "Cancelado";
                    }

                    AbonosCXP nuevo = (new AbonosCXP
                    {
                        idAbono = idAbono,
                        idCuentaPagar = cuenta,
                        idUsuario = user,
                        Abono = abono,
                        fecha = DateTime.Now,
                        formaPago = pago
                    });
                    context.AbonosCXP.Add(nuevo);
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}