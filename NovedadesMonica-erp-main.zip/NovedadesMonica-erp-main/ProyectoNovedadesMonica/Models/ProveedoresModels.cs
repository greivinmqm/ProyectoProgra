﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Models
{
    public class ProveedoresModels
    {
        public List<Proveedores> consultaProveedores()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Proveedores
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }


        public void AgregarProveedor(Proveedores proveedor)
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                contexto.Proveedores.Add(proveedor);
                contexto.SaveChanges();
            }
        }

        public Proveedores getProveedor(string id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Proveedores
                                 where x.idProveedor == id
                                 select x).FirstOrDefault();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void editarProveedor(Proveedores proveedores)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Proveedores
                                 where x.idProveedor == proveedores.idProveedor
                                 select x).FirstOrDefault();
                    datos.nombre = proveedores.nombre;
                    datos.primerApellido = proveedores.primerApellido;
                    datos.segundoApellido = proveedores.segundoApellido;
                    datos.direccion = proveedores.direccion;
                    datos.correo = proveedores.correo;
                    datos.telefono = proveedores.telefono;

        contexto.SaveChanges();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void removeProveedor(Proveedores proveedores, NovedadesMonicaEntities _contexto)
        {
            using (var contexto = _contexto)
            {
                contexto.Proveedores.Remove(proveedores);
                contexto.SaveChanges();
            }

        }
    }
}