﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models.BaseEntity;


namespace ProyectoNovedadesMonica.Models
{
    public class VentasModels
    {

        public List<Ventas> consultaVentas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    DateTime fechaAct = DateTime.Parse(DateTime.Now.ToString("dd-MM-yyyy"));
                    var datos = (from x in context.Ventas
                                 where x.fecha == fechaAct
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

            public List<Ventas> consultaVentasFechas(DateTime fechFin, DateTime fechaIni)
            {
                try
                {
                    using (var context = new NovedadesMonicaEntities())
                    {
                        DateTime fechaAct = DateTime.Parse(DateTime.Now.ToString("dd-MM-yyyy"));
                        var datos = (from x in context.Ventas
                                     where x.fecha >= fechaIni  && x.fecha <=fechFin
                                     select x).ToList();
                        return datos;
                    }
                }
                catch (Exception)
                {

                    throw;
                }
            }

        public List<ventasDetalle> detalleVenta(int id, DateTime fecha)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.ventasDetalle
                                 where x.fecha==fecha && x.idVenta == id 
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Boolean anularVenta(int id, DateTime fecha)
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Ventas
                                 where x.fecha == fecha && x.idVenta == id
                                 select x).FirstOrDefault();
                    datos.anulada = "s";
                    var detalle = (from x in context.ventasDetalle
                                where x.fecha == fecha && x.idVenta == id
                                select x).ToList();
                    foreach(var linea in detalle)
                    {
                        var prod = (from x in context.Productos
                                    where linea.idProducto == x.idProducto
                                    select x).FirstOrDefault();
                        prod.cantidad += linea.cantidad;
                    }
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

    }
}