﻿using ProyectoNovedadesMonica.ETL;
using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Models
{
    public class CuentasCobrarModels
    {

        public List<CuentasPorCobrar> cuentasCobrarActivas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities()) {

                    var datos = (from x in context.CuentasPorCobrar
                                 where x.estado == "Pendiente"
                                 select x).ToList();

                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<CuentasPorCobrar> CuentasFecha(DateTime fechaFin, DateTime fechaIni, string estado)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    if (estado == "" && fechaFin != DateTime.MinValue)
                    {
                        var datos = (from x in context.CuentasPorCobrar
                                     where x.fecha <= fechaFin && x.fecha >= fechaIni
                                     select x).ToList();
                        return datos;

                    }
                    else if (estado != "" && fechaFin == DateTime.MinValue)
                    {
                        var datos = (from x in context.CuentasPorCobrar
                                     where x.estado==estado
                                     select x).ToList();
                        return datos;

                    }
                    else
                    {
                        var datos = (from x in context.CuentasPorCobrar
                                     where x.fecha <= fechaFin && x.fecha >= fechaIni && x.estado==estado
                                     select x).ToList();
                        return datos;
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<AbonosCXC> abonosRealizados(int cuenta)
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.AbonosCXC
                                 where x.idCuentaCobrar == cuenta
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public ClsAbono nuevoAbono(int cuenta, int user)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    VentaDetalleModels model = new VentaDetalleModels();
                    var datos = (from x in context.CuentasPorCobrar
                                 where x.idCuentaCobrar == cuenta
                                 select x).FirstOrDefault();

                    ClsAbono abono = (new ClsAbono
                    {
                        idabono = model.lastIdAbono(Convert.ToDateTime(datos.fecha), cuenta),
                        idUsuario = user,
                        idCuentaCobrar = cuenta,
                        fecha= DateTime.Now,
                        pendiente = datos.pendiente.Value,
                        total = datos.total.Value
                    });

                    return abono;

                }
            }
            catch (Exception)
            {

                throw;
            } 
        }

        public List<SelectListItem> listaEstado()
        {
            try
            {
                List<SelectListItem> listaEstado = new List<SelectListItem>(); ;
                listaEstado.Add(new SelectListItem { Value = "Efectivo", Text = "Efectivo" });
                listaEstado.Add(new SelectListItem { Value = "Tarjeta", Text = "Tarjeta" });
                return listaEstado;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Boolean newAbonoModel(int cuenta, decimal abono, int idAbono, int user, string pago) 
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.CuentasPorCobrar
                                 where x.idCuentaCobrar == cuenta
                                 select x).FirstOrDefault();
                    datos.saldo += abono;
                    datos.pendiente -= abono;
                    if (datos.pendiente == 0)
                    {
                        datos.estado = "Cancelado";
                    }

                    AbonosCXC nuevo = (new AbonosCXC
                    {
                        idabono = idAbono,
                        idCuentaCobrar = cuenta,
                        idUsuario = user,
                        abono = abono,
                        fecha = DateTime.Now,
                        formaPago = pago
                    });
                    context.AbonosCXC.Add(nuevo);
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}