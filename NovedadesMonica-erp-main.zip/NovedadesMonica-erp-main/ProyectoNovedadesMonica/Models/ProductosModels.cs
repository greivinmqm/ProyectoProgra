﻿using ProyectoNovedadesMonica.Models.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProyectoNovedadesMonica.Models
{
    public class ProductosModels
    {

        public IEnumerable<Productos> getProductos()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Productos
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }           
        }

        public List<SelectListItem> listaCategorias()
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    List<SelectListItem> listaCategorias;
                    listaCategorias = (from x in contexto.Categorias
                                       select  new SelectListItem { Value = x.idCategoria.ToString(), 
                                       Text = x.nombreCategoria }).ToList();
                    return listaCategorias;
                }
                   
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        public void removeProducto(Productos productos, NovedadesMonicaEntities _contexto)
        {
            using (var contexto = _contexto)
            {
                //borra el user y se hace el commit
                contexto.Productos.Remove(productos);
                contexto.SaveChanges();
            }

        }

        public void addProducto(Productos productos)
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                //borra el user y se hace el commit
                contexto.Productos.Add(productos);
                contexto.SaveChanges();
            }

        }
    }
}