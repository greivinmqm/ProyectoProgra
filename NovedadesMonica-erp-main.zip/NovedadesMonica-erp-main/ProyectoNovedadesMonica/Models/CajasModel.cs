﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoNovedadesMonica.Models.BaseEntity;

namespace ProyectoNovedadesMonica.Models
{
    public class CajasModel
    {
        public IEnumerable<Cajas> consultaCajas()
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    var datos = (from x in context.Cajas
                                 select x).ToList();
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        public void AgregarCaja(Cajas caja, int id)
        {
            using (var contexto = new NovedadesMonicaEntities())
            {
                caja.idUsuario = id;
                contexto.Cajas.Add(caja);
                contexto.SaveChanges();
            }
        }
        public Cajas getCaja(int id)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    var datos = (from x in contexto.Cajas
                                 where x.idCaja == id
                                 select x).FirstOrDefault();

                    datos.tarjeta = totalTarjeta(datos);
                    datos.efectivo = totalEfectivo(datos);
                    return datos;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void editarCaja(Cajas cajas)
        {
            try
            {
                using (var contexto = new NovedadesMonicaEntities())
                {
                    //usamos LinQ para obtener el usuario
                    var datos = (from x in contexto.Cajas
                                 where x.idCaja == cajas.idCaja
                                 select x).FirstOrDefault();
                    //para hacer el update se va a proceder a igualar cada uno de los objetos
                    //de datos(que es como el objeto propio de la BD) y el objeto que está recibiendo por parámetros
                    //que es toda la nueva información que el usuario envió
                    datos.idUsuario = cajas.idUsuario;
                    datos.estado = "Inactivo";
                    datos.montoInicial = cajas.montoInicial;
                    datos.montoFinal = cajas.montoFinal;
                    datos.faltante = cajas.faltante;
                    datos.sobrante = cajas.sobrante;
                    datos.efectivo = cajas.efectivo;
                    datos.tarjeta = cajas.tarjeta;
                    datos.fechaInicio = cajas.fechaInicio;
                    datos.fechaCierre = cajas.fechaCierre;

                    //hago el commit
                    contexto.SaveChanges();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public decimal totalTarjeta(Cajas cajas)
        {
            try
            {
                using (var context = new NovedadesMonicaEntities())
                {
                    DateTime fecha = cajas.fechaInicio.Date;
                    var datos = (from x in context.Ventas
                                 where x.fecha == fecha && x.formaPago == "Tarjeta" && x.anulada == "n"
                                 select x).ToList();
                    decimal total = 0;
                    foreach (var linea in datos)
                    {
                        total += linea.total.Value;
                    }

                    var datosCXC = (from x in context.AbonosCXC
                                    where x.fecha == fecha && x.formaPago == "Tarjeta"
                                    select x).ToList();

                    foreach (var linea in datosCXC)
                    {
                        total += linea.abono.Value;
                    }

                    var datosCXP = (from x in context.AbonosCXP
                                    where x.fecha == fecha && x.formaPago == "Tarjeta"
                                    select x).ToList();

                    foreach (var linea in datosCXP)
                    {
                        total -= linea.Abono.Value;
                    }
                    return total;
                }
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        public decimal totalEfectivo(Cajas cajas)
        {
            try
            {
                using(var context = new NovedadesMonicaEntities())
                {
                    DateTime fecha = cajas.fechaInicio.Date;
                    var datos = (from x in context.Ventas
                                 where x.fecha == fecha && x.formaPago == "Efectivo" && x.anulada=="n"
                                 select x).ToList();

                    decimal total = 0;
                    foreach (var linea in datos)
                    {
                        total += linea.total.Value;
                    }

                    var datosCXC = (from x in context.AbonosCXC
                                    where x.fecha == fecha && x.formaPago == "Efectivo"
                                    select x).ToList();

                    foreach( var linea in datosCXC)
                    {
                        total += linea.abono.Value;
                    }

                    var datosCXP = (from x in context.AbonosCXP
                                    where x.fecha == fecha && x.formaPago == "Efectivo"
                                    select x).ToList();

                    foreach (var linea in datosCXP)
                    {
                        total -= linea.Abono.Value;
                    }


                    return total;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Boolean cajaAbierta()
        {
            try
            {
                DateTime hoy = DateTime.Today;
                DateTime manana = DateTime.Today.AddDays(1);
                using(var context = new NovedadesMonicaEntities())
                {
             
                    var datos = (from x in context.Cajas
                                 where x.estado == "Activo" || (x.fechaInicio>=hoy &&x.fechaInicio<=manana)
                                 select x).FirstOrDefault();
                    if (datos != null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}