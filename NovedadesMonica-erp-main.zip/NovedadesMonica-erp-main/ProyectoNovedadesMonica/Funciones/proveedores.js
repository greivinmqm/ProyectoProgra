﻿function createModalAddProveedor(url) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {

        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoProveedorModal").html(data);
            $("#ProveedorModal").modal('show');
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
    });
}

function createModalMantenimientoProveedor(url, id) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            id: id,
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoProveedorModal").html(data);
            $("#ProveedorModal").modal('show');
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
    });
}


function eliminarAlert(url, id) {
    swal({
        title: "¿Seguro que desea borrar el Proveedor?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        id: id,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        swal("¡Proveedor eliminado con éxito!", {
                            icon: "success",
                        });

                        setTimeout(function () {
                            location.reload();
                        }, 2000);
                    },
                    error: function (data) {
                        swal("¡El Proveedor no ha sido eliminado!");
                    }
                });

            } else {
                swal("¡El Proveedor no ha sido eliminado!");
            }
        });
}

function verifCed() {
    let ced = document.getElementById("ced").value;

    $.ajax({
        type: 'POST',
        url: '/Proveedores/revisarCedAjax',
        data: {
            cedula: ced,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {

        },
        error: function (data) {
            swal("Cédula en uso", "¡Proveedor ya registrado!", "warning");
            document.getElementById("ced").value = "";
        }
    });
}