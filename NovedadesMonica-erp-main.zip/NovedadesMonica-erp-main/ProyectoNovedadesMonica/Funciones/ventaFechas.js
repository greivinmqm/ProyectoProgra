﻿
function filtrarPorFechas() {
    let fechaIni = document.getElementById("fechaIni").value;
    let fechaFin = document.getElementById("fechaFin").value;
    if (fechaFin < fechaIni) {
        swal("¡Fecha de inicio no puede ser mayor a la fecha de fin!");
    } else {
        var url = "/Ventas/filtarFechas?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni;
        //var url = '@Url.Action("filtarFechas", "Ventas", new {fechaFin = fechaFin})';
        window.location.href = url;

        //window.location = "/Ventas/filtarFechas";

    }
}

function filtrarPorFechasAparta() {
    let fechaIni = document.getElementById("fechaIni").value;
    let fechaFin = document.getElementById("fechaFin").value;
    if (fechaFin.toString() == "" || fechaIni.toString() == "") {
        swal("Error", "¡Debe seleccionar ambas fechas", "warning");
    }
    else if (fechaFin < fechaIni) {
        swal("Error", "¡Fecha de inicio no puede ser mayor a la fecha de fin!", "warning");
    } else {
        var url = "/Apartado/filtarFechas?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni;
        //var url = '@Url.Action("filtarFechas", "Ventas", new {fechaFin = fechaFin})';
        window.location.href = url;

        //window.location = "/Ventas/filtarFechas";

    }
}


function VistaDetalleVenta(id, fecha) {
    var fecha1 = fecha.toString();
    var nueva = fecha.split(" ")[0].split("/").reverse().join("-");
    var otro = fecha1.split(" ")[0].split("/").reverse().join("-");

    var url = "/Ventas/vistaDetalleVenta?fecha=" + nueva + "&id=" + id;
    window.location.href = url;


}


function filtrarPorFechasCuenta() {
    let estado = document.getElementById("estado").value;
    let fechaIni = document.getElementById("fechaIni").value;
    let fechaFin = document.getElementById("fechaFin").value;
    if (fechaFin.toString() == "" && fechaIni.toString() == "" && estado == "") {
        swal("Error", "¡Debe elegir algún filtro!", "warning");
    }
    else if (estado=="") {


        if (fechaFin.toString() == "" || fechaIni.toString() == "") {
            swal("Error", "¡Debe seleccionar ambas fechas!", "warning");
        }
        else if (fechaFin < fechaIni) {
            swal("Error", "¡Fecha de inicio no puede ser mayor a la fecha de fin!", "warning");
        } else {
            var url = "/CuentasPorCobrar/aplicarFiltros?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni + "&estado=" + estado;
            //var url = '@Url.Action("filtarFechas", "Ventas", new {fechaFin = fechaFin})';
            window.location.href = url;
        }
    } else {
        var url = "/CuentasPorCobrar/aplicarFiltros?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni + "&estado=" + estado;
        //var url = '@Url.Action("filtarFechas", "Ventas", new {fechaFin = fechaFin})';
        window.location.href = url;

        //window.location = "/Ventas/filtarFechas";

    }

}
