﻿

function createModalAddProd(url) {
    $.ajax({
        type: 'POST',
        url: url,
        data: {

        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoProductoModal").html(data);
            $("#ProductoModal").modal('show');
        },
        error: function (data) {
            swal("Se presentó un error, inténtalo más tarde", "warning");
        }
    });
}


function eliminarProductoAlert(url, id) {
    swal({
        title: "¿Seguro que desea borrar el usuario?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        id: id,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        //aca es donde se verifica si se pudo borrar o no
                        swal("¡Producto eliminado con éxito!", {
                            icon: "success",
                        });
                        //se da un tiempo para que el usuario lea que en efecto se borró el usuario

                        setTimeout(function () {
                            //esto es para hacer un reload porque como es Ajax la pantalla no se actualiza entonces 
                            //no se ve reflejado el cambio hasta que eso suceda, por eso un hard reload. 
                            location.reload();
                        }, 2000);
                    },
                    error: function (data) {
                        swal("¡El producto no ha sido eliminado!");
                    }
                });

            } else {
                swal("¡El producto no ha sido eliminado!");
            }
        });
}

function verPrecio() {
    let precio = parseFloat(document.getElementById("precio").value);
    let costo = parseFloat(document.getElementById("costo").value);
    if (precio < costo && precio!=0) {
        swal("Precio bajo","¡El costo es mayor al precio!", "warning");
    }
}

function validarCodigo() {
    let cod = document.getElementById("codigo").value;

    $.ajax({
        type: 'POST',
        url: '/Productos/revisarCodAjax',
        data: {
            codigo: cod,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            document.getElementById.value = "";
        },
        error: function (data) {
            swal("Producto no registrado", "¡Código no encontrado!", "warning");
            document.getElementById("codigo").value = "";
        }
    });
}
