﻿
//mediando ajax se hace un llamado post al controlador con la url que se le envía donde 
//va a encontrar el método getNewUserAjax y de ahí regresa un html, que es es la vista parcial de agregar usuario 
//y con el código de un modal que se puso en el Usuario.cshtml se incorpora la vista parcial ahí
function createModalAddClient(url) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {

            },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoClienteModal").html(data);
            $("#ClienteModal").modal('show');
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
    });
}

//es parecido al metodo de arriba solo que además se envía el id del usuario para saber cuál es el
//usuario al que le dio click 
function createModalManteCliente(url, id) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            id: id,
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoClienteModal").html(data);
            $("#ClienteModal").modal('show');
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
    });
}

/*se incorporan los sweatAlerts, para eso se hizo una combinación con ajax, donde si el usuario confirma que
desea eliminar el usuario entonces
se procede a ir al método eliminarUsuario, donde se borra el usuario si el id estuviera asociado a uno y
sino se le dice al usuario que no se borraron datos.
*/
function eliminarAlert(url, id) {
    swal({
        title: "¿Seguro que desea borrar al cliente?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        id: id,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        //aca es donde se verifica si se pudo borrar o no
                        swal("¡Cliente eliminado con éxito!", {
                            icon: "success",
                        });
                        //se da un tiempo para que el usuario lea que en efecto se borró el usuario
                        
                        setTimeout(function () {
                            //esto es para hacer un reload porque como es Ajax la pantalla no se actualiza entonces 
                            //no se ve reflejado el cambio hasta que eso suceda, por eso un hard reload. 
                            location.reload();
                        }, 2000); 
                    },
                    error: function (data) {
                        swal("¡El cliente no ha sido eliminado!");
                    }
                });
                
            } else {
                swal("¡El cliente no ha sido eliminado!");
            }
        });
}