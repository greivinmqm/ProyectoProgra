﻿function validaCod() {
    let cod = document.getElementById("codigo").value;

    $.ajax({
        type: 'POST',
        url: '/Compra/revisarCodAjax',
        data: {
            codigo: cod,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            document.getElementById("codigo").value = data.idProducto;
            document.getElementById("nombre").value = data.nombre;
            document.getElementById("desc").value = data.descripcion;
            document.getElementById("categoria").value = data.idCategoria;
            document.getElementById("cantStock").value = data.cantInventario;
            document.getElementById("costo").value = data.costo;
            document.getElementById("precio").value = data.precio;
            document.getElementById("talla").value = data.Tallas;
            document.getElementById("imagen").value = data.imagen;
        },
    });
}

function eliminarLinea(url, id) {
    swal({
        title: "¿Seguro que desea borrar el producto?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        id: id,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        swal("¡Producto eliminado con éxito!", {
                            icon: "success",
                        });
                        setTimeout(function () {
                            location.reload();
                        }, 2000);
                    },
                    error: function (data) {
                        swal("¡Linea no ha sido eliminado!");
                    }
                });

            } else {
                swal("¡Linea no ha sido eliminado!");
            }
        });
}

function vaciarLineas() {

    swal({
        title: "¿Seguro que desea vaciar la Compra?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: '/Compra/limpiarLineas',
                    data: {
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        swal("¡Lineas eliminadas con éxito!", {
                            icon: "success",
                        });
                        setTimeout(function () {
                            location.reload();
                        }, 3000);
                    },
                    error: function (data) {
                        swal("Intente más tarde", "¡No ha sido posible borrar todas las lineas!", "warning");
                    }
                });
            } else {
                swal("¡No se han borrado todas la lineas!");
            }
        });
}

function verPrecio() {
    let precio = parseInt(document.getElementById("precio").value);
    let costo = parseInt(document.getElementById("costo").value);
    if (precio < costo && precio != 0) {
        swal("Precio bajo", "¡El costo es mayor al precio!", "warning");
    }
}
function addCompraModal(url) {
    $.ajax({
        type: 'POST',
        url: url,
        data: {
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoLineaModal").html(data);
            $("#LineaModal").modal('show');
        },
        error: function (data) {
            swal("Se presentó un error, intenté más tarde");
        }
    });
}

function getNewTotal() {
    let total = parseFloat(document.getElementById("total2").value);
    document.getElementById("total").innerHTML = (total);
}

function confirmaCompraAjax(url) {

    let total = parseFloat(document.getElementById("total2").value).toString();
    let transaccion = document.getElementById("transaccion").value;
    let forma = document.getElementById("forma").value;
    let proveedor = document.getElementById("Proveedor").value;
    let abono = parseFloat(document.getElementById("abono").value).toString();

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            total: total,
            transaccion: transaccion,
            forma: forma,
            proveedor: proveedor,
            abono: abono,

        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            swal("Transacción realizada con éxito!");
            setTimeout(function () {
                location.reload();
            }, 2500);
        },
        error: function (data) {
            swal("¡Se presentó un error, intenté más tarde!");
        }
    });
}

function anularCompra(id, fecha, anulada) {
    if (anulada == "n") {

        swal({
            title: "¿Seguro que desea anular la Compra " + id + " ?",
            text: "¡Si la anula, no podrá recuperarla!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {

                    $.ajax({
                        type: 'POST',
                        url: "/Compra/anularCompraAjax",
                        data: {
                            id: id,
                            fecha: fecha,
                        },
                        dataType: 'json',
                        cache: false,
                        success: function (data) {
                            swal("¡Compra anulada con éxito!", {
                                icon: "success",
                            });
                            setTimeout(function () {
                                location.reload();
                            }, 2500);
                        },
                        error: function (data) {
                            swal("¡Compra no ha sido anulada!");
                        }
                    });

                } else {
                    swal("¡Compra no ha sido anulada!");
                }
            });
    } else {
        swal("¡Compra ya fue anulada!");
    }
}

function campoPago() {
    let transaccion = document.getElementById("transaccion").value;
    if (transaccion == "Credito") {
        document.getElementById("saldo").innerHTML = "Abono inicial";
        document.getElementById('abono').type = 'number';
        $("#abono").show();


    } else {
        $("#abono").hide();

    }
}