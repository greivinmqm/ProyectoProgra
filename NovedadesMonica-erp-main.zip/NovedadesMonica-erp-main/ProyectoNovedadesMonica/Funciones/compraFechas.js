﻿function filtrarPorFechasCuenta() {
    let estado = document.getElementById("estado").value;
    let fechaIni = document.getElementById("fechaIni").value;
    let fechaFin = document.getElementById("fechaFin").value;
    if (fechaFin.toString() == "" && fechaIni.toString() == "" && estado == "") {
        swal("Error", "¡Debe elegir algún filtro!", "warning");
    }
    else if (estado == "") {


        if (fechaFin.toString() == "" || fechaIni.toString() == "") {
            swal("Error", "¡Debe seleccionar ambas fechas!", "warning");
        }
        else if (fechaFin < fechaIni) {
            swal("Error", "¡Fecha de inicio no puede ser mayor a la fecha de fin!", "warning");
        } else {
            var url = "/CuentasPorPagar/aplicarFiltros?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni + "&estado=" + estado;
            window.location.href = url;
        }
    } else {
        var url = "/CuentasPorPagar/aplicarFiltros?fechaFin=" + fechaFin + "&fechaIni=" + fechaIni + "&estado=" + estado;
        window.location.href = url;

    }

}
