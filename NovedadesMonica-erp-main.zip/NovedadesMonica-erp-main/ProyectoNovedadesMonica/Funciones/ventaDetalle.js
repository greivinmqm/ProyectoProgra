﻿function validaCod(){
    let cod = document.getElementById("codigo").value;

    $.ajax({
        type: 'POST',
        url: '/VentasDetalle/revisarCodAjax',
        data: {
            codigo: cod,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            document.getElementById("prod").value = data.idProducto;
            document.getElementById("descripcion").value = data.descripcion;
            document.getElementById("precio").value = data.precio;
            document.getElementById("cantStock").value = data.cantidad;
            document.getElementById("cant").value = "";
            document.getElementById("cant").focus();


        },
        error: function (data) {
            swal("Producto no registrado", "¡Código no encontrado!", "warning");
            document.getElementById("codigo").value = "";
            document.getElementById("codigo").focus();

        }
    });
}

function validaProd() {
    let cod = document.getElementById("prod").value;

    $.ajax({
        type: 'POST',
        url: '/VentasDetalle/revisarCodAjax',
        data: {
            codigo: cod,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            document.getElementById("codigo").value = data.idProducto;
            document.getElementById("descripcion").value = data.descripcion;
            document.getElementById("precio").value = data.precio;
            document.getElementById("cantStock").value = data.cantidad;
            document.getElementById("cant").value = "";
            document.getElementById("cant").focus();

        },
        error: function (data) {
            swal("Producto no registrado", "¡Código no encontrado!", "warning");
            document.getElementById("codigo").value = "";
            document.getElementById("codigo").focus();

        }
    });
}

function eliminarLinea(url, id){
    swal({
        title: "¿Seguro que desea borrar el producto?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        id: id,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        //aca es donde se verifica si se pudo borrar o no
                        swal("¡Producto eliminado con éxito!", {
                            icon: "success",
                        });
                        //se da un tiempo para que el usuario lea que en efecto se borró el usuario

                        setTimeout(function () {
                            //esto es para hacer un reload porque como es Ajax la pantalla no se actualiza entonces 
                            //no se ve reflejado el cambio hasta que eso suceda, por eso un hard reload. 
                            location.reload();
                        }, 2000);
                    },
                    error: function (data) {
                        swal("¡Linea no ha sido eliminado!");
                    }
                });

            } else {
                swal("¡Linea no ha sido eliminado!");
            }
        });
}

function validarCant() {
    let cant = parseInt(document.getElementById("cant").value);
    let stock= parseInt(document.getElementById("cantStock").value);
    if (cant>stock || cant <0) {
        swal("Cantidad no disponible", "¡No dispone de tantas unidades para vender!", "warning");
        document.getElementById("cant").value = "";
        document.getElementById("cant").focus();

    }
}

function vaciarLineas() {

    swal({
        title: "¿Seguro que desea vaciar venta?",
        text: "¡Si lo borra, no podrá recuperarlo!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {

                $.ajax({
                    type: 'POST',
                    url: '/VentasDetalle/limpiarLineas',
                    data: {
                    },
                    dataType: 'json',
                    cache: false,
                    success: function (data) {
                        swal("¡Lineas eliminadas con éxito!", {
                            icon: "success",
                        });
                        setTimeout(function () {
                            location.reload();
                        }, 3000);
                    },
                    error: function (data) {
                        swal("Intente más tarde", "¡No ha sido posible borrar todas las lineas!", "warning");
                    }
                });
            } else {
                swal("¡No se han borrado todas la lineas!");
            }
        });
}

function addVentaModal(url) {
    $.ajax({
        type: 'POST',
        url: url,
        data: {
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoLineaModal").html(data);
            $("#LineaModal").modal('show');
        },
        error: function (data) {
            swal("Se presentó un error, intenté más tarde");
        }
    });
}


function getNewTotal() {
    let transaccion = document.getElementById("transaccion").value;
    let descuento = parseFloat(document.getElementById("desc").value);

    if (transaccion == "Venta" && descuento>=0) {
        let total = parseFloat(document.getElementById("total2").value);
        document.getElementById("total").innerHTML = (total - total * descuento);
    } else {
        document.getElementById("total").innerHTML = parseFloat(document.getElementById("total2").value);
    }
    
}

function confirmaVentaAjax(url) {

    var descuento = (document.getElementById("desc").value).toString();
    let total = parseFloat(document.getElementById("total2").value).toString();
    let transaccion = document.getElementById("transaccion").value;
    let forma = document.getElementById("forma").value;
    let cliente = document.getElementById("cliente").value;
    let abono = parseFloat(document.getElementById("abono").value).toString();
    //let abono2 = parseFloat(document.getElementById("abono").value);
    //let total2 = parseFloat(document.getElementById("total2").value);

    //if (abono2 < total2) {


        $.ajax({
            type: 'POST',
            url: url,
            data: {
                descuento: descuento,
                total: total,
                transaccion: transaccion,
                forma: forma,
                cliente: cliente,
                abono: abono,

            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                swal("¡Transacción realizada con éxito!");
                setTimeout(function () {
                    location.reload();
                }, 2500);

            },
            error: function (data) {
                swal("Se presentó un error", "Recuerde tener una caja activa", "warning");
            }
        });
    //} else {
    //    swal("Error", "Abono es mayor al total", "warning")
    //    document.getElementById("abono").value = 0;
    //}
}


function anularVenta(id, fecha, anulada) {
    if (anulada == "n") {

        swal({
            title: "¿Seguro que desea anular la venta " + id + " ?",
            text: "¡Si la anula, no podrá recuperarla!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {

                    $.ajax({
                        type: 'POST',
                        url: "/Ventas/anularVentaAjax",
                        data: {
                            id: id,
                            fecha: fecha,
                        },
                        dataType: 'json',
                        cache: false,
                        success: function (data) {
                            //aca es donde se verifica si se pudo borrar o no
                            swal("¡Venta anulada con éxito!", {
                                icon: "success",
                            });
                            setTimeout(function () {
                                location.reload();
                            }, 2500);
                        },
                        error: function (data) {
                            swal("¡Venta no ha sido anulada!");
                        }
                    });

                } else {
                    swal("¡Venta no ha sido anulada!");
                }
            });
    } else {
        swal("¡Venta ya fue anulada!");
    }
}

function campoPago() {
    let transaccion = document.getElementById("transaccion").value;
    if (transaccion == "Apartado") {
        $("#desc").hide();
        document.getElementById("saldo").innerHTML = "Abono inicial";
        document.getElementById('abono').type = 'number';
        $("#abono").show();


    } else {
        $("#desc").show();
        document.getElementById("saldo").innerHTML = "Descuento";
        $("#abono").hide();

    }
}


