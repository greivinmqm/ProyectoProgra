﻿function calcular() {
    var bi50 = parseInt(document.getElementById('billeteCincuenta').value);
    var bi10 = parseInt(document.getElementById('billeteDiez').value);
    var bi2 = parseInt(document.getElementById('billeteDos').value);
    var bi20 = parseInt(document.getElementById('billeteVeinte').value);
    var bi5 = parseInt(document.getElementById('billeteCinco').value);
    var bi1 = parseInt(document.getElementById('billeteMil').value);
    var mo500 = parseInt(document.getElementById('MonedaQui').value);
    var mo50 = parseInt(document.getElementById('MonedaCin').value);
    var mo10 = parseInt(document.getElementById('MonedaDiez').value);
    var mo100 = parseInt(document.getElementById('MonedaCien').value);
    var mo25 = parseInt(document.getElementById('MonedaVeint').value);
    var mo5 = parseInt(document.getElementById('MonedaCinc').value);
    var tarjeta = parseInt(document.getElementById("tarjeta").value);

    var resultado = (bi50 * 50000) + (bi10 * 10000) + (bi2 * 2000) + (bi20 * 20000) + (bi5 * 5000) + (bi1 * 1000) + (mo500 * 500) +
        (mo50 * 50) + (mo10 * 10) + (mo100 * 100) + (mo25 * 25) + (mo5 * 5);
    var elemResult = document.getElementById("montoInicial").value = resultado + tarjeta;
    var total = document.getElementById("efectivo").value = resultado;

    
}



function createModalAddCaja(url) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {

        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoCajaModal").html(data);
            $("#CajaModal").modal('show');
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
    });
}

function createModalMantenimientoCaja(url, id) {

    $.ajax({
        type: 'POST',
        url: url,
        data: {
            id: id,
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoCajaModal").html(data);
            $("#CajaModal").modal('show');
           
        },
        error: function (data) {
            alert("Se presentó un problema.");
        }
        
    });
}


function calcularCaja() {
    var bi50 = parseInt(document.getElementById('billeteCincuenta').value);
    var bi10 = parseInt(document.getElementById('billeteDiez').value);
    var bi2 = parseInt(document.getElementById('billeteDos').value);
    var bi20 = parseInt(document.getElementById('billeteVeinte').value);
    var bi5 = parseInt(document.getElementById('billeteCinco').value);
    var bi1 = parseInt(document.getElementById('billeteMil').value);
    var mo500 = parseInt(document.getElementById('MonedaQui').value);
    var mo50 = parseInt(document.getElementById('MonedaCin').value);
    var mo10 = parseInt(document.getElementById('MonedaDiez').value);
    var mo100 = parseInt(document.getElementById('MonedaCien').value);
    var mo25 = parseInt(document.getElementById('MonedaVeint').value);
    var mo5 = parseInt(document.getElementById('MonedaCinc').value);
    var efectivo = parseInt(document.getElementById('efectivo').value);
    var tarjeta = parseInt(document.getElementById('tarjeta').value);

    if (tarjeta == null) {
        tarjeta = 0;
    }
    var resultado = (bi50 * 50000) + (bi10 * 10000) + (bi2 * 2000) + (bi20 * 20000) + (bi5 * 5000) + (bi1 * 1000) + (mo500 * 500) +
        (mo50 * 50) + (mo10 * 10) + (mo100 * 100) + (mo25 * 25) + (mo5 * 5);
    var elemResult = document.getElementById("montoActual").value = resultado;

    var montoFinal = efectivo + tarjeta;
    var faltante = 0;
    var sobrante = 0;

    if (efectivo > resultado) {
        var faltante = efectivo - resultado;
    } else {
        var sobrante = resultado - efectivo;
    }
    
    document.getElementById("txtFaltante").value = faltante;
    document.getElementById("sobrante").value = sobrante;
    document.getElementById("montoFinal").value = montoFinal;
   
}

function warning(url, submit){
    if (parseFloat(document.getElementById("montoActual").value) != parseInt(document.getElementById('efectivo').value) ) {
        swal({
            title: "¿Seguro que desea continuar con el cierre de caja?",
            text: "¡Ventas no son iguales al efecivo en caja!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })

    }
}