﻿function VistaAbonosCuenta(cuenta) {
    var url = "/CuentasPorPagar/vistaAbonos?cuenta=" + cuenta;
    window.location.href = url;
}

function realizarAbono(cuenta) {
    $.ajax({
        type: 'POST',
        url: "/CuentasPorPagar/vistaModalAbono",
        data: {
            cuenta: cuenta,
        },
        dataType: 'html',
        cache: false,
        success: function (data) {
            $("#ContenidoAbonoModal").html(data);
            $("#AbonoModal").modal('show');
        },
        error: function (data) {
            swal("Se presentó un error, inténtalo más tarde", "warning");
        }
    });
}

function revisarAbono() {
    let abono = parseFloat(document.getElementById("abono").value);
    let pendiente = parseFloat(document.getElementById("pendiente").value);
    let pend = parseFloat(document.getElementById("pend").value);

    if (pendiente < abono) {
        swal("Error", "Abono es mayor al saldo adeudado", "warning");
        document.getElementById("pend").value = pendiente;
        document.getElementById("abono").value = "";
    } else {
        document.getElementById("pend").value = pendiente - abono;
    }
}

function confirmaAbonoAjax(url, idCuenta, idabono) {
    $.ajax({
        type: 'POST',
        url: url,
        data: {
            idCuenta: idCuenta,
            abono: document.getElementById("abono").value,
            idabono: idabono,
            formaPago: document.getElementById("forma").value,
        },
        dataType: 'json',
        cache: false,
        success: function (data) {
            swal("¡Abono realizado con éxito!");
            var url = "/CuentasPorPagar/ConsultaCXP";
            window.location.href = url;
        },
        error: function (data) {
            swal("Se presentó un error, inténtalo más tarde", "warning");
        }
    });
}