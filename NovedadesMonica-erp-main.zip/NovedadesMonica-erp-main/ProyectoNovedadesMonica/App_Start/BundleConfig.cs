﻿using System.Web;
using System.Web.Optimization;

namespace ProyectoNovedadesMonica
{
    public class BundleConfig
    {
        // Para obtener más información sobre las uniones, visite https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Utilice la versión de desarrollo de Modernizr para desarrollar y obtener información. De este modo, estará
            // para la producción, use la herramienta de compilación disponible en https://modernizr.com para seleccionar solo las pruebas que necesite.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Content/js/jquery.min.js", 
                      "~/Content/js/popper.min.js",
                      "~/Content/js/bootstrap.min.js",
                      "~/Content/js/jquery.mCustomScrollbar.concat.min.js",
                      "~/Content/js/index/morris-chart/morris.js",
                      "~/Content/js/index/morris-chart/raphael-min.js",
                      "~/Content/js/index/morris-init.js",
                      "~/Content/js/Chart.min.js",
                      "~/Content/js/chartjs-init.js",
                      "~/Content/js/jquery.dcjqaccordion.2.7.js",
                      "~/Content/js/custom.js", 
                      "~/Content/js//jquery.dataTables.min.js",
                      "~/Content/js/dataTables.bootstrap4.min.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/js/index/morris-chart/morris.css",
                      "~/Content/css/bootstrap.min.css",
                      "~/Content/css/font-awesome.min.css",
                      "~/Content/css/ionicons.css",
                      "~/Content/css/simple-line-icons.css",
                      "~/Content/css/jquery.mCustomScrollbar.css",
                      "~/Content/css/weather-icons.min.css",
                      "~/Content/css/style.css",
                      "~/Content/css/stylesheet.css",
                      "~/Content/css/animate.min.css",
                      "~/Content/css/tree.css",
                      "~/Content/css/font-awesome.css",
                      "~/Content/css/fullcalendar.css",
                      "~/Content/css/dataTables.bootstrap4.min.css",
                      "~/Content/css/responsive.css"));                                                       
        }
    }
}
