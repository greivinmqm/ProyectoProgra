create database NovedadesMonica
use NovedadesMonica


CREATE TABLE Roles (
idRol				int  PRIMARY KEY,
nombreRol			varchar(50) not null,
descripcion			varchar(100) not null
)

CREATE   TABLE Usuarios(
idUsuario		int  identity(100,1) primary key,
cedula		varchar(15) not null,
nombre		varchar (20) not null,
primerApellido	varchar (80) not null,
segundoApellido		varchar (80) not null,
idrol				int not null,
correo varchar(100) not null,
telefono	varchar(20) not null,
contrasena				varchar(200) not null,
estado				varchar(20) not null,
 FOREIGN KEY (idRol) REFERENCES roles (idrol),
 unique(cedula, correo)
) 

CREATE TABLE Proveedores (
  idProveedor        varchar(12) NOT NULL,
  nombre            varchar(50)  NOT NULL,
  primerApellido          varchar(80)  NOT NULL,
  segundoApellido varchar (80) not null,
  direccion         varchar(200) DEFAULT NULL,
  correo             varchar(50) NOT NULL,
  telefono          varchar(50) DEFAULT NULL,
  PRIMARY KEY (idProveedor)
)
CREATE TABLE Clientes (
  idCliente         varchar(12) NOT NULL,
  nombre            varchar(50) not NULL,
  primerApellido          varchar(50) not NULL,
  segundoApellido varchar(50) not null,
  direccion         varchar(200) DEFAULT NULL,
  correo             varchar(50) NOT NULL,
  telefono          varchar(20) DEFAULT NULL,
  PRIMARY KEY (idCliente)
) 
CREATE  TABLE Categorias (
  idCategoria 	  	int identity(10,1),
  nombreCategoria 	varchar(50) NOT NULL,
  descripcion 		varchar(200) NULL,
  PRIMARY KEY (idCategoria)
)
CREATE TABLE Productos (
  idProducto 		  varchar(20),
  idCategoria 		  int NOT NULL,
  nombre 		      varchar(50)  NOT NULL,
  descripcion 		  varchar(200)  NOT NULL,
  cantidad 		      int  NOT NULL,
  Tallas		      varchar(100) not null,  
  costo 		      decimal(18,2) NOT NULL,
  precio 		      decimal(18,2)  NOT NULL,
  impuesto			  decimal(4,2) NOT NULL,
  imagen              varchar(500) DEFAULT NULL,
  PRIMARY KEY (idProducto),
  FOREIGN KEY (idCategoria) REFERENCES categorias (idCategoria)
)
CREATE  TABLE Cajas (
  idCaja			int NOT NULL,
  idUsuario         int not null ,
  estado            varchar(1) NOT NULL,
  montoInicial      decimal(18,5) NOT NULL,
  montoFinal        decimal(18,5) DEFAULT NULL,
  faltante          decimal(18,5) DEFAULT NULL,
  sobrante          decimal(18,5) DEFAULT NULL,
  efectivo          decimal(18,5) DEFAULT NULL,
  tarjeta           decimal(18,5) DEFAULT NULL,
  fechaInicio       date NOT NULL,
  fechaCierre       date DEFAULT NULL,
   FOREIGN KEY (idUsuario) REFERENCES usuarios (idUsuario),
  PRIMARY KEY (idCaja)
) 
CREATE TABLE Ventas (
  idVenta          decimal(20) NOT NULL,
  idCliente          varchar(12) DEFAULT NULL,
  idUsuario			int not null ,
  fecha			     date DEFAULT NULL,
  anulada           varchar(1) NOT NULL DEFAULT 'n',
  formaPago         varchar(50) NOT NULL,
  descuento			decimal(18,5),
  total       decimal(18,5) NULL,
  PRIMARY KEY (idVenta),
  FOREIGN KEY (idCliente) REFERENCES clientes (idCliente),
  FOREIGN KEY (idUsuario) REFERENCES usuarios (idUsuario)
) 

CREATE TABLE ventasDetalle (
  idVenta          decimal(20) NOT NULL,
  idProducto       varchar(20) NOT NULL,
  costo             decimal(18,5) NOT NULL,
  precio            decimal(18,5) NOT NULL,
  cantidad          decimal(16,3) NOT NULL,
  impuesto          decimal(4,2) NOT NULL,
  PRIMARY KEY (idVenta,idProducto),
  FOREIGN KEY (idventa) REFERENCES ventas (idventa),
  FOREIGN KEY (idProducto) REFERENCES productos (idProducto)
) 

CREATE TABLE Apartados (
  idApartado          decimal(20) NOT NULL,
  idCliente          varchar(12) DEFAULT NULL,
  idUsuario			int not null ,
  fecha			     date DEFAULT NULL,
  abono       decimal(18,5) NULL,
  total       decimal(18,5) NULL,
  PRIMARY KEY (idApartado),
  FOREIGN KEY (idCliente) REFERENCES clientes (idCliente),
  FOREIGN KEY (idUsuario) REFERENCES usuarios (idUsuario)
) 

CREATE TABLE ApartadosDetalle (
  idApartado          decimal(20) NOT NULL,
  idProducto       varchar(20) NOT NULL,
  precio            decimal(18,5) NOT NULL,
  cantidad          decimal(16,3) NOT NULL,
  impuesto          decimal(4,2) NOT NULL,
  PRIMARY KEY (idApartado,idproducto),
  FOREIGN KEY (idApartado) REFERENCES apartados (idApartado),
  FOREIGN KEY (idProducto) REFERENCES productos (idProducto)
) 

CREATE TABLE Bitacora (
	id				 int NOT NULL ,
	operacion		varchar(50) DEFAULT NULL,
	idUsuario int not null ,
    fechaModificacion datetime DEFAULT NULL,
	tabla varchar(40) NOT NULL,
PRIMARY KEY (id)
) 
CREATE TABLE CuentasPorCobrar(
idCuentaCobrar		 int NOT NULL ,
  idApartado          decimal(20) NOT NULL,
idUsuario int not null ,
 total       decimal(18,5) NULL,
 descripcion 		  varchar(200) DEFAULT NULL,
 saldo       decimal(18,5) NULL,
   fechaInicio		     date DEFAULT NULL,
     FOREIGN KEY (idApartado) REFERENCES apartados (idApartado),
   PRIMARY KEY (idCuentaCobrar)
   )

   CREATE TABLE CuentasPorPagar(
idCuentaPagar		 int NOT NULL ,
  idProveedor         varchar(12) NOT NULL,
idUsuario int not null ,
 total       decimal(18,5) NULL,
 descripcion 		  varchar(200) DEFAULT NULL,
 saldo       decimal(18,5) NULL,
   fechaInicio		     date DEFAULT NULL,
   FOREIGN KEY (idusuario) REFERENCES usuarios (idUsuario),
     FOREIGN KEY (idproveedor) REFERENCES proveedores (idProveedor),
   PRIMARY KEY (idCuentaPagar)
   )

      CREATE TABLE AbonosCXC(
	idabono		 int NOT NULL ,
	idCuentaCobrar		 int NOT NULL ,
	idUsuario int not null ,
	abono       decimal(18,5) NULL,
	 fecha		     date DEFAULT NULL,
	    FOREIGN KEY (idCuentaCobrar) REFERENCES cuentasPorCobrar (idCuentaCobrar),
		FOREIGN KEY (idUsuario) REFERENCES usuarios (idUsuario),
		 PRIMARY KEY (idCuentaCobrar,idAbono)
		 )
		       CREATE TABLE AbonosCXP(
	idAbono		 int NOT NULL ,
	idCuentaPagar		 int NOT NULL ,
	idUsuario int not null ,
	Abono       decimal(18,5) NULL,
	 fecha		     date DEFAULT NULL,
	    FOREIGN KEY (idCuentaPagar) REFERENCES cuentasPorPagar (idCuentaPagar),
		FOREIGN KEY (idusuario) REFERENCES usuarios (idUsuario),
		 PRIMARY KEY (idCuentaPagar,idAbono)
		 )



--insert de roles--
insert into Roles values (1, 'Administrador', 
'Cuenta con control total del sistema, tiene la capacidad de modificar todo en el sistema');
insert into Roles values (2, 'Colaborador', 
'No tiene acceso a todos los m�dulos del sistema, debe pedir ayuda del administrador.');

--insert de usuarios--
insert into Usuarios values('4-0151-0311', 'Marilu','Varela', 'Murillo', 1, 'marilu_varela@yahoo.com','83145605', 'mvarela123', 'Activo');
insert into Usuarios values('1-0179-0952', 'Jenny','P�rez', 'Castro', 1, 'jperez@hotmail.com','88549011', 'jperez123', 'Activo');
insert into Usuarios values('4-9045-0456', 'Luc�a','Montero', 'Gonzalez', 1, 'lmontero@yahoo.com','87549032', 'lmontero', 'Inactivo');
insert into Usuarios values('1-1166-2001', 'Ver�nica','Murillo', 'Barboza', 1, 'vmurillo@gmail.com','87207689', 'vov123', 'Activo');


--insert categor�as--

insert into Categorias values('General','Aspectos generales');
insert into Categorias values('Mujeres', 'Ropa para mujeres');
insert into Categorias values('Hombres', 'Ropa para hombres');
insert into Categorias values('Ni�os', 'Vestimenta para ni�os');
insert into Categorias values('Ni�as', 'Vestimenta para ni�as');
insert into Categorias values('Accesorios', 'Art�culos complementarios');
insert into Categorias values('Joyer�a', 'Comprende collares, pulseras, aretes y dem�s');
insert into Categorias values('Beb�s', 'Ropa para beb�s');


--insert Productos--

insert into Productos values('CLS-0201',11,'Vestido mujer', 'Vestido Azul', 10, 'S', 5500, 9000,0.13,'');
insert into Productos values('TNK-0105',12,'Tennis Jordan', 'Tennis negras casuales', 2, '43', 40000, 70000,0.13,'');
insert into Productos values('ZAP-0101',13,'Zapatos escolares', 'Zapatos escolares negros', 15, '40', 6800, 10100,0.13,'');

